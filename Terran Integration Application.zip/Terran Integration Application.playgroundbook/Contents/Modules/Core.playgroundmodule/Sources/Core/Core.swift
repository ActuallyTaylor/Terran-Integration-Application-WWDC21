import Foundation
import CoreGraphics

public struct Package {
    var cycle: Int
    var mapState: Matrix
}

public protocol CoreDelegate: AnyObject {
    
    func log(_ log: Any)
    func finishedGenerating()
    func finishedGeneration(_ package: Package)
    func failed(_ message: String)

}

public enum SimState {
    case running
    case paused
    case stopped
    case finished
}

var sim = Simulation(populationSize: 10000, worldSize: CGSize(width: 50, height: 50), speciesRegistry: nil)
var core: Core? = nil

public class Core {
    public var delegate: CoreDelegate? {
        didSet {
            delegate?.finishedGeneration(Package(cycle: sim.currentCycle, mapState: sim.world))
        }
    }
    
//    public var mapStates: [Matrix] = []
    
    public var simState: SimState = .stopped
    
    public var species: [Genus] {
        get {
            return sim.speciesRegistry
        }
        set(newValue) {
            sim.speciesRegistry = newValue
        }
    }
        
    internal var inLoop: Bool = false
    
    public init() {
        core = self
        sim.logging = false
        
        populateWorld(nil)
//        mapStates.append(sim.world)
        log(sim.world)
        NotificationCenter.default.addObserver(self, selector: #selector(resetSim), name: .ResetSim, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(reloadSim), name: .ReloadSim, object: nil)

    }
    
    @objc func reloadSim() {
        simState = .stopped
        sim.logging = false
        populateWorld(Random.uInt32(range: UInt32.min...UInt32.max))
    }
    
    @objc func resetSim() {
//        mapStates.removeAll()
        simState = .stopped
        sim.logging = false
        
        while inLoop { continue }
        
        sim.lifeForms.removeAll()
        sim = Simulation(populationSize: sim.populationSize, worldSize: CGSize(width: sim.world.rows, height: sim.world.columns), speciesRegistry: sim.speciesRegistry)
        populateWorld(Random.uInt32(range: UInt32.min...UInt32.max))
        
//        mapStates.append(sim.world)
        log(sim.world)
        delegate?.finishedGeneration(Package(cycle: sim.currentCycle, mapState: sim.world))
    }
        
    func runLoop(_ slow: Bool = false) {
        if !inLoop {
            Dispatch.background { [self] in
                let start = DispatchTime.now()
                inLoop = true
                while simState == .running {
                    let fitnessArray: [Double] = sim.lifeForms.map { (lifeform) -> Double in
                        return lifeform.getFitness()
                    }
                    
                    let averageFitness: Double = fitnessArray.average
                    sim.averageFitness = averageFitness
                    
                    for form in sim.lifeForms {
                        moveLifeForm(form: form)
                        reduceStats(form)
                        form.age += 1
                    }
                    
                    snap()
                    delegate?.finishedGeneration(Package(cycle: sim.currentCycle, mapState: sim.world))
                    log(sim.world.description)

                    sim.currentCycle += 1
                    checkFailStates()
                    
                    if slow {
                        usleep(500000) //Sleep 0.5 seconds
                    }
                }
                            
                let end = DispatchTime.now()
                let nanoTime = end.uptimeNanoseconds - start.uptimeNanoseconds
                let timeInterval = Double(nanoTime) / 1_000_000_000
                log("Simulation took \(timeInterval) seconds", true)
                inLoop = false
            }
        }
    }
    
    func checkFailStates() {
        if sim.lifeForms.count == 0 {
            simState = .finished
            delegate!.failed("All lifeforms on the planet have died. Better luck next time!")
        }
    }
}


func log(_ log: Any, _ force: Bool = false) {
    if sim.logging || force {
        if core?.delegate != nil {
            core!.delegate!.log(log)
        } else {
            print("Delegate Nil")
        }
    }
}
