import Foundation

func reduceStats(_ form: LifeForm) {
    if form.thirst >= 90 {
        form.health -= Random.double(range: 1...(7 - form.resilience.clamped(to: 0...5)))
    } else if form.hunger >= 90 {
        form.health -= Random.double(range: 1...(7 - form.resilience.clamped(to: 0...5)))
    }
    
    form.thirst += Random.double(range: 1...sim.increaseMax)
    form.urge += Random.double(range: 1...sim.increaseMax)
    form.hunger += Random.double(range: 1...sim.increaseMax)
}

//This is the fitness function that decides if a life form should live at the end of a cycle.
//https://youtu.be/_Nqz9ceoxCU?t=27
func snap() {
    for lifeForm in sim.lifeForms {
        if lifeForm.health <= 0 {
            sim.lifeForms.remove(lifeForm)
            sim.world[lifeForm.location.row, lifeForm.location.column] = Space(nil, type: .Nothing)
            log("Killed by low health \(lifeForm), at \(lifeForm.location.row), \(lifeForm.location.column) with \(lifeForm.health)")
        } else if lifeForm.hunger >= 100 {
            sim.lifeForms.remove(lifeForm)
            sim.world[lifeForm.location.row, lifeForm.location.column] = Space(nil, type: .Nothing)
            log("Killed by no food \(lifeForm), at \(lifeForm.location.row), \(lifeForm.location.column) with \(lifeForm.hunger)")
        } else if lifeForm.thirst >= 100 {
            sim.lifeForms.remove(lifeForm)
            sim.world[lifeForm.location.row, lifeForm.location.column] = Space(nil, type: .Nothing)
            log("Killed by no water \(lifeForm), at \(lifeForm.location.row), \(lifeForm.location.column) with \(lifeForm.thirst)")
        }
    }
}
