import Foundation
import SwiftUI

//A genus - Basically just a species
public class Genus: Equatable {
    var representation: String
    var name: String
    var foodchainLevel: Int
    var reproductionAge: Int
    
    var genome: Genome!
    
    //MARK: Stat calculations
    //These do not actually affect the individual life forms, they are just used to display values
    
    var totalResilience: Double {
        get {
            var value = 0.0
            for item in genome.genes {
                if item.effectSpot == .resilience {
                    value += item.affect
                }
            }
            return value
        }
    }
    
    var totalDesirability: Double {
        get {
            var value = 0.0
            for item in genome.genes {
                if item.effectSpot == .desirability {
                    value += item.affect
                }
            }
            return value
        }
    }
    
    var totalStrength: Double {
        get {
            var value = 0.0
            for item in genome.genes {
                if item.effectSpot == .strength {
                    value += item.affect
                }
            }
            return value
        }
    }
    
    internal init(representation: String, name: String, foodchainLevel: Int, reproductionAge: Int, genome: Genome? = nil) {
        self.representation = representation
        self.name = name
        self.foodchainLevel = foodchainLevel
        self.reproductionAge = reproductionAge
        self.genome = genome
    }
    
    
    public static func == (lhs: Genus, rhs: Genus) -> Bool {
        return lhs.representation == rhs.representation && lhs.name == rhs.name && lhs.foodchainLevel == rhs.foodchainLevel && lhs.reproductionAge == rhs.reproductionAge
    }
}

//A coordinate in the world
public struct Coordinate: CustomStringConvertible {
    var row: Int
    var column: Int
    
    public var description: String {
        return "x: \(row), y: \(column)"
    }
}

//A genome. Just holds genes
class Genome {
    var genes: [Gene]
    
    internal init(genes: [Gene]) {
        self.genes = genes
    }

    func mixItUp() {
        for x in 0..<genes.count {
            genes[x].affect += Random.double(range: -25..<25)
        }
    }
}

//Where a gene affects a species
public enum AffectRange {
    case desirability
    case resilience
    case strength
}

//Hold info about a gene
class Gene {
    //    var name: String
    var affect: Double
    var effectSpot: AffectRange
    
    internal init(affect: Double, effectSpot: AffectRange) {
        self.affect = affect
        self.effectSpot = effectSpot
    }
}

//MARK: Life form class
public class LifeForm: CustomStringConvertible, Equatable {
    
    var id: String
    
    //The generation
    var generation: Int
    
    //How many generations the life form lasted
    var age: Int
    
    var representation: String
    
    var location: Coordinate
    
    //MARK: Evolvable Traits
    //Determines if the mate will want to reproduce with this mate
    var desirability: Double
    
    //Determines how resilient a life form is
    var resilience: Double
    
    //Determines the strength of a life form.
    var strength: Double
    
    //MARK: Varaible Stats
    //The health of the life form, higher is better
    var health: Double = 100  {
        didSet {
            self.health = self.health.clamped(to: -100...100.0)
        }
    }
    
    //The thirst of the life form, smaller is better
    var thirst: Double = 0  {
        didSet {
            self.thirst = self.thirst.clamped(to: 0.0...100.0)
        }
    }
    
    //The hunger of the life form, smaller is better
    var hunger: Double = 0  {
        didSet {
            self.hunger = self.hunger.clamped(to: 0.0...100.0)
        }
    }
    
    
    //The urge of the animal to reproduce, smaller is better
    var urge: Double = 0  {
        didSet {
            self.urge = self.urge.clamped(to: 0.0...100.0)
        }
    }
    
    var kills: Int = 0
    
    var genus: Genus
    
    var genome: Genome
    
    init(location: Coordinate, id: String, genus: Genus, genome: Genome) {
        self.location = location
        self.id = id
        self.representation = genus.representation
        self.generation = sim.currentCycle
        self.genus = genus
        self.thirst = Random.double(range: 0...40)
        self.urge = Random.double(range: 0...40)
        self.hunger = Random.double(range: 0...40)
        self.age = 0
        self.genome = genome
        self.desirability = 0
        self.resilience = 0
        self.strength = 0

        for item in genome.genes {
            switch item.effectSpot {
            case .desirability:
                desirability += item.affect
            case .resilience:
                resilience += item.affect
            case .strength:
                strength += item.affect
            }
        }
    }
    
    public func applyGenes() {
        desirability = 0
        resilience = 0
        strength = 0
        for item in genome.genes {
            switch item.effectSpot {
            case .desirability:
                desirability += item.affect
            case .resilience:
                resilience += item.affect
            case .strength:
                strength += item.affect
            }
        }
    }
        
    public var description: String {
        return representation
    }
    
    public var stats: String {
        return "\(representation) - \(generation) ¬\n - desire: \(desirability)\n - resilience: \(resilience)\n - strength: \(strength)\n - health: \(health)\n - thirst: \(thirst)\n - urge: \(urge)\n - hunger: \(hunger)\n - fitness: \(getFitness())\n - kills: \(kills)"
    }
    
    func getFitness() -> Double {
        return desirability + resilience + strength
    }
    
    public static func == (lhs: LifeForm, rhs: LifeForm) -> Bool {
        return lhs.id == rhs.id
    }
}
