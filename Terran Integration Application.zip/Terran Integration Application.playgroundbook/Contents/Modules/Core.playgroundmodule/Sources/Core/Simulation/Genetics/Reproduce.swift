import Foundation

func reproduce(_ lifeFormOne: LifeForm, _ lifeFormTwo: LifeForm) -> LifeForm {
    let l1Genes = lifeFormOne.genome.genes
    let l2Genes = lifeFormTwo.genome.genes
    
    var genes: [Gene] = []
    for x in 0..<sim.genomeChromosomeCount {
        let lifeFormOneGene = l1Genes[x]
        let lifeFormTwoGene = l2Genes[x]

        var affect: Double = 0
        let typeSwitch = Random.int(range: 0...2)
        if typeSwitch ==  0 {
            //From Life Form 1
            affect = lifeFormOneGene.affect
        } else if typeSwitch == 1 {
            //From Life Form 2
            affect = lifeFormTwoGene.affect
        } else if typeSwitch == 2 {
            //Average of the two
            affect = (lifeFormOneGene.affect + lifeFormTwoGene.affect) / 2
        }
        
        if Random.checkPercentage_Double(percentage: 0.05) {
            affect += Random.double(range: -25...25)
        }
        
        let gene: Gene = Gene(affect: affect, effectSpot: lifeFormOneGene.effectSpot)
        genes.append(gene)
    }
    let genome = Genome(genes: genes)
    let offspring = LifeForm(location: Coordinate(row: 0, column: 0), id: UUID().uuidString, genus: lifeFormOne.genus, genome: genome)
    
    return offspring
}
