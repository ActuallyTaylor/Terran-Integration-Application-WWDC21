import Foundation

/*
 This class holds all of the information about the simulation.
 It is a giant 2D matrix that has some functions for finding neighbors around points.
 */
//Inspired by https://medium.com/@michael.m/creating-a-matrix-class-in-swift-3-0-a7ae4fee23e1
public class Matrix: CustomStringConvertible {
    internal var data: Array<Space>
    
    public var rows: Int
    public var columns: Int
    
    public subscript(row: Int, col: Int) -> Space {
        get {
            return data[(row * columns) + col]
        }
        set(newValue) {
            self.data[(row * columns) + col] = newValue
        }
    }
    
    init(_ data:Array<Space>, rows:Int, columns:Int) {
        self.data = data
        self.rows = rows
        self.columns = columns
    }
    
    init(rows:Int, columns:Int) {
        self.data = [Space](repeating: Space(nil, type: .Nothing), count: rows*columns)
        self.rows = rows
        self.columns = columns
    }
    
    public var description: String {
        var desc = ""
        for col in 0..<columns {
            for row in 0..<rows {
                let string = "\(self[row, col])"
                desc += string + ""
            }
            desc += "\n"
        }
        
        return desc
    }
    
    //Stands for Vision Circle Neighbor
    struct VSN {
        var row: Int
        var column: Int
    }
    
    /*
     Approximation of what the vision circle actually looks like. A is the current space
         ╬
       ╬ ╬ ╬
     ╬ ╬ ╬ ╬ ╬
   ╬ ╬ ╬ A ╬ ╬ ╬
     ╬ ╬ ╬ ╬ ╬
       ╬ ╬ ╬
         ╬
     */
    func visionCircle(row: Int, column: Int) -> [WorldSpace] {
        var spaces: [WorldSpace] = []
        let directionChanges: [VSN] = [
            //MARK: Directly Touchable Neighbors
            //0, 3, 6, 9, 12, 15, 18, 21
            
            //MARK: North
            VSN(row: row - 1, column: column), //0
            VSN(row: row - 2, column: column), //1
            VSN(row: row - 3, column: column), //2
            
            //MARK: East
            VSN(row: row, column: column + 1), //3
            VSN(row: row, column: column + 2), //4
            VSN(row: row, column: column + 3), //5
            
            //MARK: South
            VSN(row: row + 1, column: column), //6
            VSN(row: row + 2, column: column), //7
            VSN(row: row + 3, column: column), //8
            
            //MARK: West
            VSN(row: row, column: column - 1), //9
            VSN(row: row, column: column - 1), //10
            VSN(row: row, column: column - 1), //11
            
            //MARK: Top Right Corner
            VSN(row: row - 1, column: column + 1), //12
            VSN(row: row - 2, column: column + 1), //13
            VSN(row: row - 1, column: column + 2), //14
            
            //MARK: Top Left Corner
            VSN(row: row - 1, column: column - 1), //15
            VSN(row: row - 2, column: column - 1), //16
            VSN(row: row - 1, column: column - 2), //17
            
            //MARK: Bottom Right Corner
            VSN(row: row + 1, column: column + 1), //18
            VSN(row: row + 2, column: column + 1), //19
            VSN(row: row + 1, column: column + 2), //20
            
            //MARK: Bottom Left Corner
            VSN(row: row + 1, column: column - 1), //21
            VSN(row: row + 2, column: column - 1), //22
            VSN(row: row + 1, column: column - 2), //23
        ]
        
        
        //Check if the VSN is within bounds
        for change in directionChanges {
            //Check if it is in bounds
            if change.row >= 0 && change.row < self.rows && change.column >= 0 && change.column < self.columns {
                spaces.append(WorldSpace(row: change.row, column: change.column, space: self[change.row, change.column]))
            } else {
                spaces.append(WorldSpace(row: change.row, column: change.column, space: Space(nil, type: .Nothing), outOfBounds: true))
            }
        }
        return spaces
    }
}
