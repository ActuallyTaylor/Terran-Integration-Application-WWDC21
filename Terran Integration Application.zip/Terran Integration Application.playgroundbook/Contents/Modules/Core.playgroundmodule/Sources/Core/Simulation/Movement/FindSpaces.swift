import Foundation

//Returns the closest movable neighbor. Used if a life form finds something they need outside their directly movable radius
func neighborCorners(index: Int) -> Int {
    if index == 1 || index == 2 {
        return 0
    } else if index == 4 || index == 5 {
        return 3
    } else if index == 7 || index == 8 {
        return 6
    } else if index == 10 || index == 11 {
        return 9
    } else if index == 13 || index == 14 {
        return 12
    } else if index == 16 || index == 17 {
        return 15
    } else if index == 19 || index == 20 {
        return 18
    } else if index == 22 || index == 23 {
        return 21
    }
    return 0
}

//Finds all the open neighbors in a group of world spaces
func findOpenNeighbors(neighbors: [WorldSpace]) -> WorldSpace? {
    let space = neighbors.first { (space) -> Bool in
        return !space.outOfBounds && space.space.type == .Nothing
    }
    return space
}
