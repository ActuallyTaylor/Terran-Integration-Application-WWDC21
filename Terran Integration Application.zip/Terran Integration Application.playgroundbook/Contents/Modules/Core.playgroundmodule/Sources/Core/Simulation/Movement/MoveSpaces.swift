import Foundation

//Move to a space. Handles the logic for moving life forms
public func moveSpace(_ spot: WorldSpace, neighbors: [WorldSpace], lifeForm: LifeForm) {
    let emptySpace = Space(nil, type: .Nothing)
    let row = lifeForm.location.row
    let column = lifeForm.location.column
    
    //    log(lifeForm.id)
    if !spot.outOfBounds {
        if spot.space.type == .Nothing {
            //Spot is empty so lets move to it
            log("Move")
            sim.world[spot.row, spot.column] = sim.world[row, column]
            sim.world[row, column] = emptySpace
            lifeForm.location = Coordinate(row: spot.row, column: spot.column)
        } else if spot.space.type == .LifeForm {
            //Spot is another lifeform, lets see if they want to mate, or fight
            if let possibleMate = sim.world[spot.row, spot.column].occupant,
               let openNeighbor = findOpenNeighbors(neighbors: neighbors) {
                if lifeForm.genus == possibleMate.genus {
                    //The Same species
                    let cutOff: Double = 80
                    if lifeForm.getFitness() > sim.speciesFitness(lifeForm.genus) && lifeForm.age > lifeForm.genus.reproductionAge && lifeForm.hunger < cutOff && lifeForm.thirst < cutOff && possibleMate.hunger < cutOff && possibleMate.thirst < cutOff  && possibleMate.age > possibleMate.genus.reproductionAge {
                        
                        if 100 - possibleMate.desirability < Random.double(range: 0...100) {
                            log("Reproducing: \(lifeForm) \(lifeForm.desirability) >> \(possibleMate) \(possibleMate.desirability)", false)
                            let offspring = reproduce(lifeForm, possibleMate)
                            offspring.location = Coordinate(row: openNeighbor.row, column: openNeighbor.column)
                            
                            sim.lifeForms.append(offspring)
                            sim.world[openNeighbor.row, openNeighbor.column] = Space(offspring, type: .LifeForm)
                            possibleMate.urge = 0
                            lifeForm.urge = 0
                        } else {
                            log("Failed to reproduce:  \(lifeForm) >> \(possibleMate)")
                        }
                    }
                } else {
                    //Not the same species
                    if possibleMate.genus.foodchainLevel > lifeForm.genus.foodchainLevel {
                        if possibleMate.strength > lifeForm.resilience {
                            log("\(possibleMate) \(possibleMate.strength) killed \(lifeForm) \(lifeForm.resilience)")
                            sim.world[row, column] = emptySpace
                            
                            sim.lifeForms.remove(lifeForm)
                            possibleMate.hunger += lifeForm.hunger
                            possibleMate.kills += 1
                        }
                    } else if lifeForm.genus.foodchainLevel > possibleMate.genus.foodchainLevel {
                        if lifeForm.strength > possibleMate.resilience {
                            log("\(lifeForm) \(lifeForm.strength) killed \(possibleMate) \(possibleMate.resilience)")
                            sim.world[possibleMate.location.row, possibleMate.location.column] = emptySpace
                            
                            sim.lifeForms.remove(possibleMate)
                            lifeForm.hunger += possibleMate.hunger
                            lifeForm.kills += 1
                        }
                    } else if lifeForm.genus.foodchainLevel == possibleMate.genus.foodchainLevel {
                        if lifeForm.strength > possibleMate.resilience {
                            log("\(lifeForm) \(lifeForm.strength) killed \(possibleMate) \(possibleMate.resilience)")
                            sim.world[possibleMate.location.row, possibleMate.location.column] = emptySpace
                            
                            sim.lifeForms.remove(possibleMate)
                            lifeForm.hunger += possibleMate.hunger
                            lifeForm.kills += 1
                        } else if possibleMate.strength > lifeForm.resilience {
                            log("\(possibleMate) \(possibleMate.strength) killed \(lifeForm) \(lifeForm.resilience)")
                            sim.world[row, column] = emptySpace
                            
                            sim.lifeForms.remove(lifeForm)
                            possibleMate.hunger += lifeForm.hunger
                            possibleMate.kills += 1
                        }

                    }
                }
            }
        } else if spot.space.type == .Food {
            lifeForm.hunger -= Random.double(range: 0...100)
            log("\(lifeForm) - Increase Health \(lifeForm.health)")
        } else if spot.space.type == .Water {
            lifeForm.thirst -= Random.double(range: 0...100)
            log("\(lifeForm) - Decrease Thirst \(lifeForm.thirst)")
        } else {
            moveLifeForm(form: lifeForm)
        }
    }
}

//Figures out where a life form needs to move
func moveLifeForm(form: LifeForm) {
    let neighbors = sim.world.visionCircle(row: form.location.row, column: form.location.column)
    let directlyTouchingNeighborIndices = [0, 3, 6, 9, 12, 15, 18, 21]

//    let avoidSpaces: [WorldSpace] = neighbors.filter { (space) -> Bool in
//        return space.space.occupant?.genus.foodchainLevel ?? 0 > form.genus.foodchainLevel
//    }

    let avoidSpaces: [WorldSpace] = []

    if neighbors.contains(where: { (space) -> Bool in
        if !space.outOfBounds {
            return space.space.occupant?.genus.foodchainLevel ?? 100 < form.genus.foodchainLevel
        } else {
            return false
        }
    }) {
        log("\(form) - Fight")
        tryMoving(form: form, type: .LifeForm, avoid: avoidSpaces)
        return
    }
    
    //Find What We Need to do
    if form.hunger > form.urge && form.hunger > form.thirst {
        //We are most thirsty so look for water to drink
        log("\(form) - Hunger")
        tryMoving(form: form, type: .Food, avoid: avoidSpaces)
        return
    }
    if form.thirst > form.urge && form.thirst > form.hunger {
        //We are most thirsty so look for water to drink
        log("\(form) - Thirsty")
        tryMoving(form: form, type: .Water, avoid: avoidSpaces)
        return
    }
    if form.urge > form.thirst && form.urge > form.hunger {
        //Our urge is the highest so we must look for a mate
        log("\(form) - Reproduce")
        tryMoving(form: form, type: .LifeForm, avoid: avoidSpaces)
        return
    }
    
    moveSpace(neighbors[directlyTouchingNeighborIndices.randomElement() ?? 0], neighbors: neighbors, lifeForm: form)
    return
}

func tryMoving(form: LifeForm, type: SpaceType, avoid: [WorldSpace]) {
    let neighbors = sim.world.visionCircle(row: form.location.row, column: form.location.column)
//    neighbors.removeAll { (ws) -> Bool in
//        return avoid.contains { (ws2) -> Bool in
//            return ws2 == ws
//        }
//    }
    let directlyTouchingNeighborIndices = [0, 3, 6, 9, 12, 15, 18, 21]
//    directlyTouchingNeighborIndices.removeAll { (int) -> Bool in
//        return int >= neighbors.count
//    }

    var foundSpot = false
    for x in 0..<neighbors.count {
        if !directlyTouchingNeighborIndices.contains(x) {
            //Neighbor is directly touchable
            let neighbor = neighbors[x]
            if !neighbor.outOfBounds {
                if neighbor.space.type == type {
                    foundSpot = true
                    log("\(form) - Move to \(neighbor.space)")
                    moveSpace(neighbor, neighbors: neighbors, lifeForm: form)
                    return
                }
            }
        }
    }
    if !foundSpot {
        for x in 0..<neighbors.count {
            if directlyTouchingNeighborIndices.contains(x) {
                let neighbor = neighbors[x]
                if !neighbor.outOfBounds {
                    if neighbor.space.type == type {
                        //Move to the closest possible neighbor.
                        log("\(form) - Move to closest \(neighbor.space)")
                        foundSpot = true
                        moveSpace(neighbors[neighborCorners(index: x)], neighbors: neighbors, lifeForm: form)
                        return
                    }
                }
            }
        }
    }
    if !foundSpot {
        log("Not found")
        moveSpace(neighbors[directlyTouchingNeighborIndices.randomElement() ?? 0], neighbors: neighbors, lifeForm: form)
        return
    }
}
