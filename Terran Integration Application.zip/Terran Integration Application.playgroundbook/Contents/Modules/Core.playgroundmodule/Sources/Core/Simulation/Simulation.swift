import Foundation
import CoreGraphics

//Test colors
//⬜️🟫⬛️🟥🟧🟨🟩🟦🟪
//Simulation is declared here
public class Simulation {
    var populationSize: Int = 100
    var currentCycle: Int = 0
    
    var retryCount: Int = 100
        
    var world: Matrix = Matrix(rows: 25, columns: 25)
    
    var lifeForms: [LifeForm] = []
    
    var averageFitness: Double = 0.0
    
    //MARK: Sim Details
    var logging: Bool = false
    
    var increaseMax: Double = 10
        
    var startingSpeciesCount: Int = 4
    
    var genomeChromosomeCount: Int = 8 {
        didSet {
            if genomeChromosomeCount != oldValue {
                for x in 0..<self.speciesRegistry.count {
                    if self.speciesRegistry[x].genome == nil {
                        let genome = generateGenome(startingCount: self.genomeChromosomeCount)
                        self.speciesRegistry[x].genome = genome
                    }
                }
            }
        }
    }
    
    public var speciesRegistry: [Genus] = [
//        Genus(representation: "🐶", name: "Dog", foodchainLevel: 3, reproductionAge: 3),
//        Genus(representation: "🐱", name: "Cat", foodchainLevel: 3, reproductionAge: 3),
//        Genus(representation: "🐭", name: "Mouse", foodchainLevel: 2, reproductionAge: 3),
//        Genus(representation: "🐲", name: "Dragon", foodchainLevel: 4, reproductionAge: 3)
        
        //Test Species - You can turn these on to better see the vornoi noise stuff
//        Genus(representation: "🟫", name: "Brown", foodchainLevel: 3, reproductionAge: 4),
//        Genus(representation: "⬛️", name: "Black", foodchainLevel: 2, reproductionAge: 4),
//        Genus(representation: "🟥", name: "Red", foodchainLevel: 4, reproductionAge: 4),
//        Genus(representation: "🟧", name: "Orange", foodchainLevel: 3, reproductionAge: 4),
//        Genus(representation: "🟨", name: "Yellow", foodchainLevel: 3, reproductionAge: 4),
//        Genus(representation: "🟩", name: "Green", foodchainLevel: 2, reproductionAge: 4),
//        Genus(representation: "🟦", name: "Blye", foodchainLevel: 4, reproductionAge: 4),
//        Genus(representation: "🟪", name: "Purple", foodchainLevel: 4, reproductionAge: 4)
    ]

    init(populationSize: Int, worldSize: CGSize, speciesRegistry: [Genus]?) {
        self.populationSize = populationSize
        self.world = Matrix(rows: Int(worldSize.width), columns: Int(worldSize.height))
        
        if speciesRegistry != nil {
            self.speciesRegistry = speciesRegistry!
        } else {
            let possible = "🐶🐱🐭🐹🐰🦊🐻🐼🐻‍❄️🐨🐯🦁🐮🐷🐸🐵🐔🐧🐦🐤🐲🦄🦋🐙🐍🐝🐳🦀🐴🐺🐗🦉🐛🐞"
            while self.speciesRegistry.count < startingSpeciesCount {
                let rep: String = String(possible.randomElement() ?? "🐶")
                
                if self.speciesRegistry.contains(where: { (gen) -> Bool in return gen.representation == rep }) { continue }
                
                let foodchainLevel = Random.int(range: 1...startingSpeciesCount)
                let reproductionAge = Random.int(range: 3..<5)
                let species = Genus(representation: rep, name: getEmojiName(rep), foodchainLevel: foodchainLevel, reproductionAge: reproductionAge)
                self.speciesRegistry.append(species)
            }
            //Assign a genome to every exsisting species that does not have one
            for x in 0..<self.speciesRegistry.count {
                if self.speciesRegistry[x].genome == nil {
                    let genome = generateGenome(startingCount: self.genomeChromosomeCount)
                    self.speciesRegistry[x].genome = genome
                }
            }
        }
    }
    
    //Figure out a species fitness
    func speciesFitness(_ species: Genus) -> Double {
        let speciesMembers = lifeForms.filter { (life) -> Bool in
            return life.genus == species
        }
        let fitnessArray: [Double] = speciesMembers.map { (lifeform) -> Double in
            return lifeform.getFitness()
        }
        
        let averageFitness: Double = fitnessArray.average
        return averageFitness
    }
    
    
    func getEmojiName(_ emoji: String) -> String {
        switch emoji {
        case "🐶":
            return "Dog"
        case "🐱":
            return "Cat"
        case "🐭":
            return "Mouse"
        case "🐹":
            return "Hamster"
        case "🐰":
            return "Rabbit"
        case "🦊":
            return "Fox"
        case "🐻":
            return "Bear"
        case "🐼":
            return "Panda"
        case "🐻‍❄️":
            return "Polar Bear"
        case "🐨":
            return "Koala Bear"
        case "🐯":
            return "Tiger"
        case "🦁":
            return "Lion"
        case "🐮":
            return "Cow"
        case "🐷":
            return "Pig"
        case "🐸":
            return "Frog"
        case "🐵":
            return "Monkey"
        case "🐔":
            return "Chicken"
        case "🐧":
            return "Penguin"
        case "🐦":
            return "Bird"
        case "🐤":
            return "Chick"
        case "🐲":
            return "Dragon"
        case "🦄":
            return "Unicorn"
        case "🦋":
            return "Butterfly"
        case "🐙":
            return "Octopus"
        case "🐍":
            return "Snake"
        case "🐝":
            return "Bee"
        case "🐳":
            return "Whale"
        case "🦀":
            return "Crab"
        case "🐴":
            return "Horse"
        case "🐺":
            return "Wolf"
        case "🐗":
            return "Boar"
        case "🦉":
            return "Owl"
        case "🐛":
            return "Caterpillar"
        case "🐞":
            return "Lady Bug"
        default:
            return "Null"
        }
    }

}
