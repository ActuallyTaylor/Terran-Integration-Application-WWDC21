import Foundation
import GameplayKit

//Generates a species genome. These genes influence a species ability to change.
func generateGenome(startingCount: Int) -> Genome {
    let genome = Genome(genes: [])
    for n in 0..<startingCount {
        let value = Random.double(range: -10...100)

        var type = Random.int(range: 0..<3)
        var traitType: AffectRange = .desirability
        if n < 3 {
            type = n
        }
        
        if type == 0 {
            traitType = .desirability
        } else if type == 1 {
            traitType = .resilience
        } else if type == 2 {
            traitType = .strength
        }
        
        let chromosome = Gene(affect: value, effectSpot: traitType)
        genome.genes.append(chromosome)
    }
    genome.genes.shuffle()

    return genome
}

//Generates life forms in groups across map.
func populateSpace(_ seed: UInt32?) {
    let cutOff: Double = 0.4
    let seed: UInt32 = seed ?? Random.uInt32(range: UInt32.min...UInt32.max)
    
    let vornoi = VeronoiNoise(seed: seed, sampleSize: 15, size: vector_int2(Int32(sim.world.rows), Int32(sim.world.columns)))
    
    var heights: [Double] = []

    if sim.speciesRegistry.count == 0 {
        return
    }
    for row in 0..<sim.world.rows {
        for column in 0..<sim.world.columns {
            let value = vornoi.value(vector_double2(Double(row), Double(column)))
            let height = value.0 / 10
            let point = value.1
            heights.append(Double(height))
            
            if sim.lifeForms.count < sim.populationSize {
                if sim.world[row, column] == Space(nil, type: .Nothing) {
                    if Double(height) < cutOff {
                        let animalIndex = point.type.clamped(to: 0..<sim.speciesRegistry.count - 1)

                        let genus = sim.speciesRegistry[animalIndex]
                        var genes: [Gene] = []
                        
                        for item in genus.genome!.genes {
                            genes.append(Gene(affect: item.affect, effectSpot: item.effectSpot))
                        }
                        let genome = Genome(genes: genes)
                        genome.mixItUp()
                        
                        let form = LifeForm(location: Coordinate(row: row, column: column), id: UUID().uuidString, genus: genus, genome: genome)
                        
                        sim.lifeForms.append(form)
                        sim.world[row, column] = Space(form, type: .LifeForm)
                    }
                }
            }
        }
    }
}

//Create the world based on noise. Creates the trees, and water
func populateWorld(_ seed: UInt32?) {
    let seed: UInt32 = seed ?? Random.uInt32(range: UInt32.min...UInt32.max)
    log("Generating with seed \(seed)")
    let map = generatePerlin(seed: Int32(truncatingIfNeeded: seed), rows: Int32(sim.world.rows), columns: Int32(sim.world.columns))
    let foodMap = generatePerlin(seed: Int32(truncatingIfNeeded: seed.hashValue), rows: Int32(sim.world.rows), columns: Int32(sim.world.columns))

    for row in 0..<sim.world.rows {
        for column in 0..<sim.world.columns {
            let location = vector2(Int32(row), Int32(column))
            let terrainHeight = map.value(at: location)
            let foodHeight = foodMap.value(at: location)

            if terrainHeight < -0.5 {
                let space = Space(nil, type: .Water)
                sim.world[row, column] = space
            } else {
                let space = Space(nil, type: .Nothing)
                sim.world[row, column] = space
                if foodHeight <= -0.8 {
                    let space = Space(nil, type: .Food)
                    sim.world[row, column] = space
                }
            }
        }
    }

    //Creates life
    populateSpace(seed)
}
