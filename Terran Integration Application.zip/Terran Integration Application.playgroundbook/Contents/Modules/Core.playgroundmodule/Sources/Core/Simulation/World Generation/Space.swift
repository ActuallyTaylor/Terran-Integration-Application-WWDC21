import Foundation

//A space in the world
public struct WorldSpace: Equatable {
    var row: Int
    var column: Int
    var space: Space
    var outOfBounds: Bool = false
}

//A type of the space. Tells the world space what kind of space it is
enum SpaceType {
    case LifeForm
    case Water
    case Food
    case Nothing
}

//A space, this is what is stored in a world space. If it contains an occupent their is a species in that space. Also determines the rendering
public class Space: CustomStringConvertible, Equatable {
    var type: SpaceType
    var occupant: LifeForm?
    
    public var description: String {
        switch type {
        case .LifeForm:
            if occupant != nil {
                return String(describing: occupant!)
            } else {
                return  "🌲"
            }
        case .Water:
            return "🌊"
        case .Food:
            return "🌸"
        case .Nothing:
            return  "🌲"//"⬜️"
        }
    }
    
    init(_ occupant: LifeForm?, type: SpaceType) {
        self.occupant = occupant
        self.type = type
    }
    
    public static func == (lhs: Space, rhs: Space) -> Bool {
        return lhs.description == rhs.description
    }
}
