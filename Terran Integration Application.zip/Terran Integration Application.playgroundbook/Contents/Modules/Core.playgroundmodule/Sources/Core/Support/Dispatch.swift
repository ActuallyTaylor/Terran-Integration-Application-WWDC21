import Foundation

public typealias Dispatch = DispatchQueue

//Dispatch thingy. Basicaly makes working with threads easy.
extension Dispatch {

    public static func background(_ task: @escaping () -> Void) {
        Dispatch.global(qos: .background).async {
            task()
        }
    }

    public static func main(_ task: @escaping () -> Void) {
        Dispatch.main.async {
            task()
        }
    }
    
    public static func delay(seconds: Double, _ task: @escaping () -> Void) {
        Dispatch.main.asyncAfter(deadline: .now() + seconds) {
            task()
        }
    }
}
