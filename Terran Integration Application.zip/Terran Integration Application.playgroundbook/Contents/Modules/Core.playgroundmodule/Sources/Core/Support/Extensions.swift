import Foundation
import SwiftUI

//MARK: 3rd Part Extensions
// https://stackoverflow.com/questions/36110620/standard-way-to-clamp-a-number-between-two-values-in-swift
extension Comparable {
    func clamped(to limits: ClosedRange<Self>) -> Self {
        return min(max(self, limits.lowerBound), limits.upperBound)
    }
}

//https://stackoverflow.com/questions/43703823/how-to-find-the-average-value-of-an-array-swift
extension Array where Element == Double {
    /// The average value of all the items in the array
    var average: Double {
        if self.isEmpty {
            return 0.0
        } else {
            let sum = self.reduce(0, +)
            return Double(sum) / Double(self.count)
        }
    }
    
}

//MARK: Custom Extensions
extension Array where Element == Int {
    mutating func remove(_ element: Int) {
        self.removeAll { (value) -> Bool in
            return value == element
        }
    }
}

extension Array where Element == LifeForm {
    mutating func remove(_ element: LifeForm) {
        self.removeAll { (value) -> Bool in
            return value == element
        }
    }
}

extension Comparable {
    func clamped(to limits: Range<Self>) -> Self {
        return min(max(self, limits.lowerBound), limits.upperBound)
    }
}

extension NumberFormatter {
    static var decimal: NumberFormatter {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        return formatter
    }
}
