import Foundation
import GameplayKit

//Game Kit's perlin noise - Works but not used
func generatePerlin(seed: Int32, rows: Int32, columns: Int32) -> GKNoiseMap {
    let source = GKPerlinNoiseSource()
    source.persistence = 0.9
    source.seed = seed
    
    let noise = GKNoise(source)
    let size = vector2(1.0, 1.0)
    let origin = vector2(0.0, 0.0)
    let sampleCount = vector2(rows, columns)
    
    return GKNoiseMap(noise, size: size, origin: origin, sampleCount: sampleCount, seamless: true)
}

//Game Kit's billow noise - Works but not used
func generateBillowNoise(seed: Int32, rows: Int32, columns: Int32) -> GKNoiseMap {
    let source = GKBillowNoiseSource()
    source.persistence = 0.9
    source.seed = seed
    
    let noise = GKNoise(source)
    let size = vector2(1.0, 1.0)
    let origin = vector2(0.0, 0.0)
    let sampleCount = vector2(rows, columns)
    
    return GKNoiseMap(noise, size: size, origin: origin, sampleCount: sampleCount, seamless: true)
}

//Game Kit's veronoi noise, does not work - It always returns the same value
func generateVoronoiNoise(seed: Int32, rows: Int32, columns: Int32, frequency: Double) -> GKNoiseMap {
    let source = GKVoronoiNoiseSource()
    source.seed = seed
    source.frequency = 1
    source.displacement = 1
    
    let noise = GKNoise(source)
    let size = vector2(20.0, 20.0)
    let origin = vector2(0.0, 0.0)
    let sampleCount = vector2(rows, columns)
    
    return GKNoiseMap(noise, size: size, origin: origin, sampleCount: sampleCount, seamless: true)
}

struct point {
    var position: vector_double2
    var type: Int
}

/// A class that creates voronoi noise. Lightly based on https://thebookofshaders.com/12/
/// I learned about random number generation in swift from https://stackoverflow.com/questions/54821659/swift-4-2-seeding-a-random-number-generator.
class VeronoiNoise {
    var seed: UInt32
    var sampleSize: Int
    var samplePoints: [point] = []
    
    //x and y represent width and height respectively
    var size: vector_int2
    
    init(seed: UInt32, sampleSize: Int, size: vector_int2) {
        let randomNumberGenerator = GKMersenneTwisterRandomSource(seed: UInt64(seed))
        self.seed = seed
        self.sampleSize = sampleSize
        self.size = size
        
        let width = size.x
        let height = size.y
        
        //Generate random points within the graph
        for _ in 0..<sampleSize {
            let x = Double(randomNumberGenerator.nextInt(upperBound: Int(width)))
            let y = Double(randomNumberGenerator.nextInt(upperBound: Int(height)))
            samplePoints.append(point(position: vector2(x, y), type: randomNumberGenerator.nextInt(upperBound: sim.speciesRegistry.count)))
        }
    }
    
    func value(_ value: vector_double2) -> (Float, point) {
        var mDistance: Float = 100000000.0
        var smallestPoint: point = samplePoints[0]
        for i in 0..<sampleSize {
            let simd1 = SIMD2(Float(value.x), Float(value.y))
            let simd2 = SIMD2(Float(samplePoints[i].position.x), Float(samplePoints[i].position.y))
            let dist = distance(simd1, simd2)
            
            if dist < mDistance {
                mDistance = dist
                smallestPoint = samplePoints[i]
            }
        }
        return (mDistance, smallestPoint)
    }

}
