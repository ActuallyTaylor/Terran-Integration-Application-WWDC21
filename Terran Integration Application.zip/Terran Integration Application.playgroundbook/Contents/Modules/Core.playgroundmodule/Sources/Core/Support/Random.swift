import Foundation

//Random class
//This makes it easy to handle random values
struct Random {
    static func int(range: ClosedRange<Int>) -> Int {
        return Int.random(in: range)
    }
    
    static func int(range: Range<Int>) -> Int {
        return Int.random(in: range)
    }
    
    static func double(range: ClosedRange<Double>) -> Double{
        return Double.random(in: range)
    }
    
    static func double(range: Range<Double>) -> Double{
        return Double.random(in: range)
    }
    
    static func int32(range: ClosedRange<Int32>) -> Int32 {
        return Int32.random(in: range)
    }
    
    static func int32(range: Range<Int32>) -> Int32 {
        return Int32.random(in: range)
    }
    
    static func uInt32(range: ClosedRange<UInt32>) -> UInt32 {
        return UInt32.random(in: range)
    }
    
    static func uInt32(range: Range<UInt32>) -> UInt32 {
        return UInt32.random(in: range)
    }

    static func float(range: ClosedRange<Float>) -> Float {
        return Float.random(in: range)
    }
    
    static func float(range: Range<Float>) -> Float {
        return Float.random(in: range)
    }
    
    static func checkPercentage_Double(percentage: Double) -> Bool {
        return double(range: 0...100) < percentage * 100
    }
    
    static func bool() -> Bool {
        let integer = int(range: 0...1)
        if integer == 0 {
            return false
        } else {
            return true
        }
    }
}

