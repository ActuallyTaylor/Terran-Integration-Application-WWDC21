//
//  ContentViewHandler.swift
//  Generations.ios
//
//  Created by Zachary lineman on 4/12/21.
//

import SwiftUI

//Handles what needs to be displayed to the user
public class ContentViewHandler: ObservableObject {
    
    enum ViewState {
        case terminal
        case simulation
        case editor
    }

    @Published var viewToShow: ViewState = .terminal
    @Published var terminalCollapsed = false
    
    var hasOpenedSim: Bool = false
    var hasOpenedEditor: Bool = false
    var hasOpenedGeneEditor: Bool = false

    init() {
        NotificationCenter.default.addObserver(self, selector: #selector(openSim), name: .StartSim, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(openTerminal), name: .StartTerminal, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(openEditor), name: .StartGeneEditing, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(triggerNotification), name: .StartGenusEditing, object: nil)

    }
    
    @objc func triggerNotification() {
        if !hasOpenedGeneEditor {
            hasOpenedGeneEditor = true
            NotificationCenter.default.post(name: .NewQuip, object: self, userInfo: ["text": "Hey! Welcome to the gene editor. In here, you can edit the starting genes for a species. Each gene affects a different stat for the species. That effect is shown above the value of the gene.\nHave fun editing!", "show": false, "position": VerticalAlignment.bottom, "positionTwo": HorizontalAlignment.center, "return": VerticalAlignment.top, "returnTwo": HorizontalAlignment.trailing])
        }
    }

    @objc func openTerminal() {
        NotificationCenter.default.post(name: .NewQuip, object: self, userInfo: ["position": VerticalAlignment.top, "positionTwo": HorizontalAlignment.trailing, "prompt": false, "stop": false])
        withAnimation(Animation.easeInOut) {
            terminalCollapsed = false
            viewToShow = .terminal
        }
        
    }
    
    @objc func openSim() {
        if !hasOpenedSim {
            hasOpenedSim = true
            NotificationCenter.default.post(name: .NewQuip, object: self, userInfo: ["text": "Looks like you’ve found the simulator. Now you can watch all of your changes to the simulation make it flourish! Or ruin it...", "show": false, "position": VerticalAlignment.bottom, "positionTwo": HorizontalAlignment.trailing, "return": VerticalAlignment.top, "returnTwo": HorizontalAlignment.trailing])

        }
        withAnimation(Animation.easeInOut) {
            terminalCollapsed = true
            viewToShow = .simulation
        }
    }
    
    @objc func openEditor() {
        if !hasOpenedEditor {
            hasOpenedEditor = true
            NotificationCenter.default.post(name: .StartGeneEditingTutorial, object: nil)
        }
        withAnimation(Animation.easeInOut) {
            terminalCollapsed = true
            viewToShow = .editor
        }
    }
}
