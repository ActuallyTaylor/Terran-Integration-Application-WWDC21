//
//  CoreHandler.swift
//  Generations.ios
//
//  Created by Zachary lineman on 4/12/21.
//

import SwiftUI

//Handles the everything to deal with the simulation
public class CoreHandler: ObservableObject, CoreDelegate {
    enum OperationAction {
        case go
        case forward
//        case backward
    }
    
    let core = Core()
    
    @Published var columns: Int = 0
    @Published var rows: Int = 0
    @Published var matrix: Matrix?
    @Published var cycle: Int = 0
    @Published var started: Bool = false
    @Published var speciesRegState: [Genus] = []
    @Published var inSession: Bool = false
    @Published var update: Bool = false
    
    var speciesRegistry: [Genus] {
        get {
            return core.species
        }
        set(newValue) {
            core.species = newValue
            speciesRegState = speciesRegistry
        }
    }
    
    @Published var finished: Bool = false
   
    @Published var frameRate: Int = 1

    var operation: OperationAction = .go
    
    //How many cycles it takes to update a frame. Lower will mean more frames updated. Higher means less frames
    
    internal var lastUpdatedFrame: Int = 0
    
    internal var internalCycle: Int = 0

    init() {
        core.delegate = self
        speciesRegState = speciesRegistry
        inSession = false
        NotificationCenter.default.addObserver(self, selector: #selector(memoryWarning), name: UIApplication.didReceiveMemoryWarningNotification, object: self)
    }
    
    @objc func memoryWarning() {
        core.simState = .paused
        print("Memory Warning")
    }
    
    func fastForwardSim() {
        operation = .forward
        started = true
        core.simState = .running
        core.runLoop(true)
    }
    
    func updateSim() -> Bool {
        if core.simState == .stopped || core.simState == .paused {
            started = true
            inSession = true
            core.simState = .running
            core.runLoop()
            return true
        } else {
            started = false
            core.simState = .paused
            return false
        }
    }
    
    @objc func restartSim() {
        core.resetSim()
        started = false
        inSession = false
    }
    
    public func log(_ log: Any) {
        print(log)
    }
    
    public func finishedGeneration(_ package: Package) {
        Dispatch.main { [self] in
            if lastUpdatedFrame + frameRate <= internalCycle || operation == .forward || internalCycle == 0 {
                lastUpdatedFrame = internalCycle
                rows = package.mapState.rows
                columns = package.mapState.columns
                matrix = package.mapState
                cycle = package.cycle + 1
            }
            internalCycle = package.cycle
            
            if operation == .forward {
                core.simState = .paused
                operation = .go
                self.started = false
            }
        }
    }
    
    public func failed(_ message: String) {
        core.simState = .finished
        NotificationCenter.default.post(name: .NewQuip, object: self, userInfo: ["text": message, "show": false, "position": VerticalAlignment.center, "positionTwo": HorizontalAlignment.center, "return": VerticalAlignment.top, "returnTwo": HorizontalAlignment.trailing])
    }
    
    public func finishedGenerating() {
        Dispatch.main {
            self.started = false
            if self.core.simState == .finished {
                
            }
        }
    }
}

