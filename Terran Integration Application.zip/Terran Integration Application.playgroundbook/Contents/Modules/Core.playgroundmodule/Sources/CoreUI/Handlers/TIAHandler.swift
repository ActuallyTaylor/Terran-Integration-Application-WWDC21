//
//  TIAHandler.swift
//  Generations.ios
//
//  Created by Zachary lineman on 4/14/21.
//

import SwiftUI

//A handler for T.I.A. Handles questions and stuff along with the flashing.
public class TIAHandler: NSObject, ObservableObject {
    
    @Published var text: String = ""
    @Published var showQuestions: Bool = false
    @Published var questions: [String] = []
    @Published var promptShown: Bool = false
    @Published var eyeColor: Color = Color.black
    @Published var eyeTime: Double = 0.1

    @Published var position: VerticalAlignment = VerticalAlignment.center
    @Published var positionTwo: HorizontalAlignment = HorizontalAlignment.center
    
    public var angry: Bool = false
    public var angerLevel: Int = 0
    
    public var lastAngry: Date = Date()
    
    internal var inStory: Bool = false
    
    internal var nextStorySection: ((_ answer :String) -> ())? = nil
    internal var lastStorySection: ((_ answer :String) -> ())? = nil

    internal var currentTextId: UUID = UUID()
    
    var angerPrompts: [Int: String] = [
        1: "Yes? You know poking me repeatedly won’t do anything.",
        3: "Okay I lied, if you poke me enough maybe I’ll give you a prize.",
        5: "Hah! You thought this was going to be quick.",
        15: "I’m still here! But ouch this is starting to hurt.",
        20: "Okay can you stop now?",
        21: "Welp your still poking me, well have fun. I'm gonna go now.",
        50: "Okay fine, that’s enough. Here my eye is now green. Are you happy?",
        51: "I guess not…"
    ]

    override init() {
        super.init()
        nextStorySection = welcomeInteraction
        NotificationCenter.default.addObserver(self, selector: #selector(changeText(_:)), name: .NewQuip, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(startGeneEditingTutorial), name: .StartGeneEditingTutorial, object: nil)

        rotateEyeColor()
    }
    
    func sayAngry() {
        if let prompt = angerPrompts.first(where: { (arg0) -> Bool in
            let (key, _) = arg0
            return key == angerLevel - 3
        }) {
            NotificationCenter.default.post(name: .NewQuip, object: self, userInfo: ["text": prompt.value, "show": false, "timer": 5])
        }
    }
    
    @objc func startGeneEditingTutorial() {
        inStory = false
        text = ""
        showQuestions = false
        nextStorySection = editorOne
        advanceStory()
    }
    
    func dismiss() {
        inStory = false
        withAnimation {
            text = ""
            questions = []
            promptShown = false
            position = .top
            positionTwo = .trailing
        }
    }
    
    func next() {
        advanceStory()
    }
    
    func back() {
        promptShown = true
        inStory = true
        rotateEyeColor()
        if lastStorySection != nil {
            lastStorySection!("")
        }
    }
    
    func faq() {
        if !inStory {
            withAnimation {
                self.text = "Hey! Can I help you out with something?"
                self.questions = [
                    "How do I get started?",
                    "How do I create a new species?",
                    "How can I edit a life form individually?",
                    "How can I edit an entire species?",
                    "My simulation is taking a really long time.",
                    "I'm good thank you!"
                ]
                self.inStory = true
                self.promptShown = true
                self.showQuestions = true
                nextStorySection = answerHandler(_:)
            }
        }
    }
    
    func rotateEyeColor() {
        eyeTime = 3
        if inStory {
            withAnimation {
                eyeColor = Color.green
            }
            Dispatch.delay(seconds: eyeTime) {
                withAnimation {
                    self.eyeColor = Color.black
                }
                Dispatch.delay(seconds: self.eyeTime) {
                    self.rotateEyeColor()
                }
            }
        } else {
            eyeTime = 0.1
        }
    }
    
    @objc func changeText(_ notification: Notification) {
        Dispatch.main { [self] in
            let id = UUID()
            currentTextId = id
            var returnSpot: VerticalAlignment?
            var returnSpotTwo: HorizontalAlignment?
            var moveBack = true
            var timer: Double = 10
            
            self.nextStorySection = nil
            self.lastStorySection = nil
            self.inStory = true
            rotateEyeColor()
            withAnimation {
                promptShown = true

                if let text = notification.userInfo?["text"] as? String {
                    self.text = text
                }
                if let prompt = notification.userInfo?["prompt"] as? Bool {
                    self.promptShown = prompt
                }
                
                if let show = notification.userInfo?["show"] as? Bool {
                    self.showQuestions = show
                }
                if let questions = notification.userInfo?["questions"] as? [String] {
                    self.questions = questions
                    if questions.count > 0 {
                        showQuestions = true
                    } else {
                        showQuestions = false
                    }
                } else {
                    self.questions = []
                }
                
                if let position = notification.userInfo?["position"] as? VerticalAlignment {
                    self.position = position
                }
                if let position = notification.userInfo?["positionTwo"] as? HorizontalAlignment {
                    self.positionTwo = position
                }
            }
            
            if let stop = notification.userInfo?["stop"] as? Bool {
                self.inStory = stop
            }

            if let rSpot = notification.userInfo?["return"] as? VerticalAlignment {
                returnSpot = rSpot
            }
            if let rSpot = notification.userInfo?["returnTwo"] as? HorizontalAlignment {
                returnSpotTwo = rSpot
            }
            if let move = notification.userInfo?["moveBack"] as? Bool {
                moveBack = move
            }
            if let time = notification.userInfo?["timer"] as? Double {
                timer = time
            }

            if moveBack {
                Dispatch.delay(seconds: timer) {
                    if id == self.currentTextId {
                        self.inStory = false
                        withAnimation {
                            self.text = ""
                            self.questions = []
                            self.promptShown = false
                            if let returnSpot = returnSpot {
                                self.position = returnSpot
                            }
                            if let returnSpot = returnSpotTwo {
                                self.positionTwo = returnSpot
                            }
                        }
                    }
                }
            }
        }
    }
    
    public func advanceStory(_ answer: String = "") {
        promptShown = true
        inStory = true
        rotateEyeColor()
        if nextStorySection != nil {
            nextStorySection!(answer)
        }
    }
    
    @objc func answerHandler(_ answer: String = "") {
        if answer == "Yes I am" {
            yesIAm(answer)
        } else if answer == "No I am not" {
            noIamNot(answer)
        } else if answer == "Okay let’s go!" {
            letsGo(answer)
        } else if answer == "Genetic Simulation?" {
            geneticSim(answer)
        } else if answer == "How do I create a new species?" {
            faqCreateNewSpecies()
        } else if answer == "How can I edit a life form individually?" {
            faqEditLife()
        } else if answer == "How can I edit an entire species?" {
            faqEditSpecies()
        } else if answer == "My simulation is taking a really long time." {
            faqSlowSim()
        } else if answer == "How do I get started?" {
            faqStart()
        } else if answer == "I have more questions" {
            inStory = false
            faq()
        } else if answer == "See you later!" || answer == "I'm good thank you!" || answer == "Thank you!" {
            withAnimation(Animation.easeInOut) {
                text = ""
                questions = []
                promptShown = false
                self.inStory = false
                self.position = .top
                self.positionTwo = .trailing
            }
        }
    }
    
    //MARK: Editor Tutorial
    @objc func editorOne(_ answer: String = "") {
        questions = []
        withAnimation(Animation.easeInOut) {
            self.position = VerticalAlignment.bottom
            self.positionTwo = HorizontalAlignment.center
            text = "Hey! You’ve found the simulation editor. This application allows you to edit the settings of the genetic simulation."
            showQuestions = false
        }
        lastStorySection = nil
        nextStorySection = editorTwo
    }
    
    @objc func editorTwo(_ answer: String = "") {
        withAnimation(Animation.easeInOut) {
            self.position = VerticalAlignment.bottom
            self.positionTwo = HorizontalAlignment.center
            text = "To add a new species just tap on the add species button in the upper right hand corner. This will let you create your own species!"
            showQuestions = false
        }
        lastStorySection = editorOne
        nextStorySection = editorThree

    }

    @objc func editorThree(_ answer: String = "") {
        withAnimation(Animation.easeInOut) {
            self.position = VerticalAlignment.bottom
            self.positionTwo = HorizontalAlignment.center
            text = "Once you have added a new species you can edit it by tapping on it in the species registry.\nHave Fun!"
            showQuestions = false
        }
        lastStorySection = editorTwo
        nextStorySection = nil
        inStory = false
    }
    
    //MARK: FAQ STORY
    @objc func faqCreateNewSpecies(_ answer: String = "") {
        withAnimation(Animation.easeInOut) {
            text = "To create a new species you must first open the editor by typing -edit- into the terminal. There you will find a button that says -Add A New Species-. You then will need to enter all of the information about your new species."
            showQuestions = true
            questions = ["I have more questions", "Thank you!"]
        }
    }
    
    @objc func faqEditLife(_ answer: String = "") {
        withAnimation(Animation.easeInOut) {
            text = "To edit a singular life form, tap / click it on the map. This will cause the quick info to show. From there you will be able to change the life forms genes by selecting edit genes."
            showQuestions = true
            questions = ["I have more questions", "Thank you!"]
        }
    }
    
    @objc func faqEditSpecies(_ answer: String = "") {
        withAnimation(Animation.easeInOut) {
            text = "To edit an entire species genome go to the edit menu by typing -edit- into the terminal. From there you will be able to click on a species and edit their genome."
            showQuestions = true
            questions = ["I have more questions", "Thank you!"]
        }
    }
    
    @objc func faqSlowSim(_ answer: String = "") {
        withAnimation(Animation.easeInOut) {
            text = "If your simulation is running slowly you can increase the frame interval. This will cause the simulation to visually happen slower but in the background it is working even faster because it does not need to wait for UI reloads."
            showQuestions = true
            questions = ["I have more questions", "Thank you!"]
        }
    }
    
    @objc func faqStart(_ answer: String = "") {
        withAnimation(Animation.easeInOut) {
            text = "To start the genetic simulation type -start- into the terminal.\n\nTo edit the genetic simulation type -edit- into the terminal."
            showQuestions = true
            questions = ["I have more questions", "Thank you!"]
        }
    }
    
    //MARK: Welcome Story Line
    @objc func welcomeInteraction(_ answer: String = "") {
        withAnimation(Animation.easeInOut) {
            text = "Hello 👋 I am T.I.A"
            showQuestions = true
            questions = ["Who are you?"]
        }
        lastStorySection = welcomeInteraction
        nextStorySection = whoAmI
    }
    
    @objc func whoAmI(_ answer: String = "") {
        withAnimation(Animation.easeInOut) {
            text = "Who am I? I am T.I.A. I was created to help primitive species like you learn how life operates."
            showQuestions = true
            questions = ["Wdym primitive?"]
        }
        lastStorySection = whoAmI
        nextStorySection = primitiveQ
    }
    
    @objc func primitiveQ(_ answer: String = "") {
        withAnimation(Animation.easeInOut) {
            text = "Well... Your species has yet to figure out how to create life... My species rates you at a tier 2 species."
            showQuestions = true
            questions = ["What is a tier 2 species?"]
        }
        lastStorySection = primitiveQ
        nextStorySection = tier2Explanation
    }
    
    
    @objc func tier2Explanation(_ answer: String = "") {
        withAnimation(Animation.easeInOut) {
            text = "Tier 2 is when you are able to interact with computers. That is why I have decided to appear to you as a terminal. I believe you should be familiar with one of these. "
            showQuestions = true
            questions = ["Yes I am", "No I am not"]
        }
        lastStorySection = tier2Explanation
        nextStorySection = answerHandler
    }
    
    @objc func yesIAm(_ answer: String = "") {
        withAnimation(Animation.easeInOut) {
            text = "Great!\nWell you can get started using the terminal right away. If you wish to edit the settings of the genetic simulation you can enter the command -edit- if you wish to start just type -start-."
            showQuestions = true
            questions = ["Okay let’s go!", "Genetic Simulation?"]
        }
        lastStorySection = yesIAm
        nextStorySection = answerHandler
    }
    
    @objc func noIamNot(_ answer: String = "") {
        withAnimation(Animation.easeInOut) {
            text = "Okay let’s get you up to speed. A terminal is a way that humans invented to interact with a computer. You can type what you want to do into the terminal and the computer will do what you say. A common command found in terminals is -help- this will display a list of all possible commands the terminal accepts."
            showQuestions = true
            questions = ["I Got this!"]
        }
        lastStorySection = noIamNot
        nextStorySection = gotThis
    }
    
    @objc func gotThis(_ answer: String = "") {
        withAnimation(Animation.easeInOut) {
            text = "Great!\nNow you can use the terminal. If you wish to edit the settings of the genetic simulation you can enter the command edit if you wish to start just type -start-."
            showQuestions = true
            questions = ["Okay let’s go!", "Genetic Simulation?"]
        }
        lastStorySection = gotThis
        nextStorySection = answerHandler
    }
    
    @objc func letsGo(_ answer: String = "") {
        withAnimation(Animation.easeInOut) {
            text = "Have fun playing around! I will chime in whenever I think you need help or there’s something I haven’t told you about yet. If you want to summon me just tap and I will help out."
            showQuestions = true
            questions = ["See you later!"]
        }
        lastStorySection = letsGo
        nextStorySection = answerHandler
    }
    
    @objc func geneticSim(_ answer: String = "") {
        withAnimation(Animation.easeInOut) {
            text = "The genetic simulation that you have access to allows you too edit the conditions of life across the planet. Once you have edited the conditions to your need you will be able to run the simulation and see how your settings affected the growth of the population."
            showQuestions = true
            questions = ["Okay let’s go!"]
        }
        lastStorySection = geneticSim
        nextStorySection = letsGo
    }
}

