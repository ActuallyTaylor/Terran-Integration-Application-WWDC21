//
//  EditScreens.swift
//  Generations.ios
//
//  Created by Zachary lineman on 4/12/21.
//

import SwiftUI

public struct SpeciesView: View {
    @ObservedObject public var model: CoreHandler
    @State var openAdd: Bool = false
    @Binding var showGeneEditor: Bool
    @Binding var genusIndex: Int
    
    @Environment(\.colorScheme) var colorScheme

    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
    ]

    public var body: some View {
        VStack {
            //Toolbar
            HStack {
                Text("Species Registry")
                    .font(.system(size: 40, design: .monospaced))

                Spacer()
                Button("Add A New Species") {
                    openAdd.toggle()
                }
                .frame(width: 175, height: 35)
                .background(Color(UIColor.systemBlue))
                .foregroundColor(.white)
                .cornerRadius(7)
                .padding()
                .popover(isPresented: $openAdd) {
                    AddSpeciesView(model: model, openAdd: $openAdd)
                }
            }
            ScrollView([.vertical]) {
                LazyVGrid(columns: columns) {
                    ForEach(0..<model.speciesRegState.count, id: \.self) { n in
                        let species = model.speciesRegState[n]
                        VStack(spacing: 0) {
                            HStack() {
                                Text(species.representation)
                                    .font(.system(size: 80, design: .monospaced))
                                Text(species.name)
                                    .font(.system(size: 22, design: .monospaced))
                                    .foregroundColor(Color(UIColor.terminalForegroundOpposite))
                            }
                            .frame(width: 250, height: 100)
                            .background(Color(UIColor.terminalBackgroundOpposite))
                            .cornerRadius(radius: 7, corners: [.topLeft, .topRight])
                            VStack {
                                Text("Foodchain Level \(species.foodchainLevel)")
                                    .font(.system(size: 18, design: .monospaced))
                                    .padding(EdgeInsets(top: 5, leading: 0, bottom: 0, trailing: 0))
                                Divider()
                                    .padding(0)
                                Text("Reproduction Age \(species.reproductionAge)")
                                    .font(.system(size: 18, design: .monospaced))
                                    .padding(EdgeInsets(top: 0, leading: 0, bottom: 10, trailing: 0))
                            }
                            .frame(width: 250)
                            .background(Color(UIColor.systemGray5))
                            .cornerRadius(radius: 7, corners: [.bottomLeft, .bottomRight])
                        }
                        .onTapGesture {
                            genusIndex = n
                            NotificationCenter.default.post(Notification(name: Notification.Name.StartGenusEditing))
                            withAnimation(Animation.easeInOut) {
                                showGeneEditor = true
                            }
                        }
                    }
                }
            }
        }
        .background(Color(UIColor.terminalBackground))
    }
}

public struct AddSpeciesView: View {
    @ObservedObject public var model: CoreHandler
    @State var speciesRepresentation: String = ""
    @State var speciesName: String = ""
    @State var foodchainLevel: String = "3"
    @State var reproductionAge: String = "3"
    @Binding var openAdd: Bool
    
    @Environment(\.colorScheme) var colorScheme

    public var body: some View {
        VStack {
            HStack {
                Image(systemName: "control")
                    .foregroundColor(.secondary)
                Text("+")
                    .foregroundColor(.secondary)
                Image(systemName: "command")
                    .foregroundColor(.secondary)
                Text("+")
                    .foregroundColor(.secondary)
                Text("space")
                    .foregroundColor(.secondary)
            }
            .padding(EdgeInsets(top: 5, leading: 0, bottom: 5, trailing: 0))
            TextField("", text: $speciesRepresentation)
                .frame(width: 65, height: 65)
                .font(.system(size: CGFloat(45)))
                .multilineTextAlignment(.center)
                .onReceive(speciesRepresentation.publisher.collect()) {
                    if let string = $0.last ?? $0.prefix(1).first {
                        self.speciesRepresentation = String(string)
                    }
                }
                .background(Color(.secondarySystemBackground))
                .cornerRadius(7)
                .padding(5)

            TextField("Name", text: $speciesName)
                .frame(width: 200, height: 25)
                .font(.system(size: 18, design: .monospaced))
                .multilineTextAlignment(.center)
                .background(Color(.secondarySystemBackground))
                .cornerRadius(7)
                .padding(3)

            HStack {
                Text("Foodchain Level: ")
                TextField("3", text: $foodchainLevel)
                    .frame(width: 75, height: 25)
                    .font(.system(size: 18, design: .monospaced))
                    .multilineTextAlignment(.center)
                    .keyboardType(.numberPad)
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(7)
            }
            
            HStack {
                Text("Reproduction Age: ")
                TextField("5", text: $reproductionAge)
                    .frame(width: 75, height: 25)
                    .font(.system(size: 18, design: .monospaced))
                    .multilineTextAlignment(.center)
                    .keyboardType(.numberPad)
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(7)
            }
            
            Button("Create Species") {
                let foodChain = Int(foodchainLevel) ?? 3
                let reproduction = Int(reproductionAge) ?? 3
                let genome = generateGenome(startingCount: sim.genomeChromosomeCount)
                model.speciesRegistry.append(Genus(representation: speciesRepresentation, name: speciesName, foodchainLevel: foodChain, reproductionAge: reproduction, genome: genome))
                openAdd = false
                NotificationCenter.default.post(Notification(name: .ReloadSim))
            }
            .frame(width: 135, height: 35)
            .background(Color(.systemBlue))
            .foregroundColor(.white)
            .cornerRadius(7)
            .padding()
        }
        .frame(width: 245, alignment: .center)
    }
}

public struct GeneEditorView: View {
    @ObservedObject public var model: CoreHandler
    @State var species: Genus
    @State var update: Bool = false
    @Binding var showGeneEditor: Bool
    var index: Int

    @Environment(\.colorScheme) var colorScheme

    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
    ]
    
    public var body: some View {
        VStack {
            ZStack(alignment: Alignment(horizontal: .center, vertical: .top)) {
                VStack(spacing: 0) {
                    HStack(alignment: VerticalAlignment.center) {
                        Text(species.representation)
                            .font(.system(size: 100, design: .monospaced))
                        Text(species.name)
                            .font(.system(size: 40, design: .monospaced))
                        Divider()
                            .frame(height: 100)
                        VStack(alignment: HorizontalAlignment.leading) {
                            Text("Resilience")
                                .font(.system(size: 18, design: .monospaced))
                            Text("\(species.totalResilience)")
                                .font(.system(size: 14, design: .monospaced))
                                .foregroundColor(.secondary)
                            Text("Strength")
                                .font(.system(size: 18, design: .monospaced))
                            Text("\(species.totalStrength)")
                                .font(.system(size: 14, design: .monospaced))
                                .foregroundColor(.secondary)
                        }

                        Divider()
                            .frame(height: 100)
                        VStack(alignment: HorizontalAlignment.leading) {
                            Text("Desirability")
                                .font(.system(size: 18, design: .monospaced))
                            Text("\(species.totalDesirability)")
                                .font(.system(size: 14, design: .monospaced))
                                .foregroundColor(.secondary)
                            Text("Total Fitness")
                                .font(.system(size: 18, design: .monospaced))
                            Text("\(species.totalStrength + species.totalResilience + species.totalDesirability)")
                                .font(.system(size: 14, design: .monospaced))
                                .foregroundColor(.secondary)
                        }
                    }
                    HStack {
                        HStack {
                            Text("Foodchain Level: ")
                            TextField("Age", value: $species.foodchainLevel, formatter: NumberFormatter.decimal)
                                .frame(width: 75, height: 25)
                                .font(.system(size: 18, design: .monospaced))
                                .multilineTextAlignment(.leading)
                                .keyboardType(.numberPad)
                                .background(Color(.systemGray5))
                                .cornerRadius(7)
                        }
                        
                        HStack {
                            Text("Reproduction Age: ")
                            TextField("Age", value: $species.reproductionAge, formatter: NumberFormatter.decimal)
                                .frame(width: 75, height: 25)
                                .font(.system(size: 18, design: .monospaced))
                                .multilineTextAlignment(.leading)
                                .keyboardType(.numberPad)
                                .background(Color(.systemGray5))
                                .cornerRadius(7)
                        }
                    }
                }
                HStack(alignment: VerticalAlignment.top) {
                    Button("Delete Species") {
                        withAnimation(Animation.easeInOut) {
                            model.speciesRegistry.remove(at: index)
                            NotificationCenter.default.post(Notification(name: .ReloadSim))
                            showGeneEditor = false
                        }
                    }
                    .frame(width: 175, height: 35)
                    .background(Color(UIColor.systemRed))
                    .foregroundColor(.white)
                    .cornerRadius(7)
                    .padding()
                    Button("Regenerate Species Genome") {
                        withAnimation(Animation.easeInOut) {
                            NotificationCenter.default.post(Notification(name: .ReloadSim))

                            let genome = generateGenome(startingCount: sim.genomeChromosomeCount)
                            species.genome = genome
                            
                            update.toggle()
                        }
                    }
                    .frame(width: 225, height: 35)
                    .background(Color(UIColor.systemGreen))
                    .foregroundColor(.white)
                    .cornerRadius(7)
                    .padding()
                    Spacer()

                    Spacer()
                    Button(action: {
                        withAnimation(Animation.easeInOut) {
                            NotificationCenter.default.post(Notification(name: .ReloadSim))
                            showGeneEditor = false
                        }
                    }) {
                        Image(systemName: "xmark")
                            .frame(width: 35, height: 35)
                            .background(Color(.systemRed))
                            .cornerRadius(22.5)
                            .padding()
                            .foregroundColor(.white)
                    }
                }
                if update {
                    Text("")
                        .hidden()
                }
            }
            HStack {
                Text("Species' Genes")
                    .font(.system(size: 40, design: .monospaced))
                Spacer()
            }
            ScrollView([.vertical]) {
                LazyVGrid(columns: columns) {
                    ForEach(0..<species.genome!.genes.count, id: \.self) { n in
                        let gene = species.genome!.genes[n]
                        VStack {
                            Text(gene.effectSpot == AffectRange.desirability ? "Desirability" : gene.effectSpot == AffectRange.resilience ? "Resilience" : "Strength")
                                .font(.system(size: 18, design: .monospaced))
                                .padding(EdgeInsets(top: 20, leading: 0, bottom: 0, trailing: 0))
                            TextField( "Double Value", value: $species.genome.genes[n].affect, formatter: NumberFormatter.decimal, onCommit: {
                                update.toggle()
                            })
                                .font(.system(size: 18, design: .monospaced))
                                .keyboardType(.decimalPad)
                                .foregroundColor(Color(UIColor.label))
                                .frame(width: 100, height: 25)
                                .background(Color(.secondarySystemBackground))
                                .cornerRadius(7)
                            HStack() {
                                Spacer()
                                Text("\(n)")
                                    .font(.system(size: 18, design: .monospaced))
                                    .foregroundColor(.secondary)
                                    .padding()
                            }
                        }
                        .frame(width: 150, height: 115)
                        .background(Color(UIColor.systemBackground))
                        .cornerRadius(7)
                        .padding(5)
                    }
                }
            }
        }
        .background(Color(UIColor.terminalBackground))
    }
}
