//
//  LifeFormCell.swift
//  Generations.ios
//
//  Created by Zachary lineman on 4/11/21.
//

import SwiftUI

public struct cell: View {
    @ObservedObject var model: CoreHandler
    var row: Int
    var column: Int
    @Binding var textSize: Int
    
    @State var opened: Bool = false
    
    @Environment(\.colorScheme) var colorScheme

    public var body: some View {
        HStack {
            Button(model.matrix![row, column].description) {
                withAnimation {
                    self.opened.toggle()
                }
            }
            .font(.system(size: CGFloat(textSize)))
        }
        .popover(isPresented: $opened) {
            let selectedSpace = model.matrix![row, column]
            if let occupent = selectedSpace.occupant {
                popoverView(model: model, selectedOrganism: occupent, selectedCoordinate: Coordinate(row: row, column: column))
            } else {
                if selectedSpace.type == .Water  || selectedSpace.type == .Food || selectedSpace.type == .Nothing{
                    popoverView(model: model, selectedOrganism: LifeForm(location: Coordinate(row: 0, column: 0), id: "", genus: Genus(representation: "❌", name: "Nothing Selected", foodchainLevel: 0, reproductionAge: 0), genome: Genome(genes: [])))
                }
            }
        }
    }
}

public struct popoverView: View {
    
    @State var model: CoreHandler
    
    @State var selectedOrganism: LifeForm = LifeForm(location: Coordinate(row: 0, column: 0), id: "", genus: Genus(representation: "❌", name: "Nothing Selected", foodchainLevel: 0, reproductionAge: 0), genome: Genome(genes: []))
        
    @State var selectedCoordinate: Coordinate = Coordinate(row: 0, column: 0)

    @State var showGenome: Bool = false
    
    @Environment(\.colorScheme) var colorScheme

    public var body: some View {
        VStack {
            Text("\(selectedOrganism.description)")
                .font(.system(size: CGFloat(60)))
            Text("\(selectedOrganism.genus.name)")
                .font(.system(size: CGFloat(15)))
            Text("\(getFormattedString(selectedOrganism.location))")
                .font(.system(size: CGFloat(10)))
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(0)
            Text("\(selectedOrganism.id)")
                .font(.system(size: CGFloat(8)))
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(0)
            Button("Edit Genes") {
                showGenome.toggle()
            }
            List {
                HStack {
                    Text("Generation >> ")
                        .font(.system(size: CGFloat(12)))
                    Text("\(getFormattedString(selectedOrganism.generation))")
                        .font(.system(size: CGFloat(12)))
                        .foregroundColor(.secondary)
                }
                HStack {
                    Text("Age >> ")
                        .font(.system(size: CGFloat(12)))
                    Text("\(getFormattedString(selectedOrganism.age))")
                        .font(.system(size: CGFloat(12)))
                        .foregroundColor(.secondary)
                }
                HStack {
                    Text("Desirability >> ")
                        .font(.system(size: CGFloat(12)))
                    Text("\(getFormattedString(selectedOrganism.desirability))")
                        .font(.system(size: CGFloat(12)))
                        .foregroundColor(.secondary)
                }
                HStack {
                    Text("Resilience >> ")
                        .font(.system(size: CGFloat(12)))
                    Text("\(getFormattedString(selectedOrganism.resilience))")
                        .font(.system(size: CGFloat(12)))
                        .foregroundColor(.secondary)
                }
                HStack {
                    Text("Strength >> ")
                        .font(.system(size: CGFloat(12)))
                    Text("\(getFormattedString(selectedOrganism.strength))")
                        .font(.system(size: CGFloat(12)))
                        .foregroundColor(.secondary)
                }
                HStack {
                    Text("Health >> ")
                        .font(.system(size: CGFloat(12)))
                    Text("\(getFormattedString(selectedOrganism.health))")
                        .font(.system(size: CGFloat(12)))
                        .foregroundColor(.secondary)
                }
                HStack {
                    Text("Hunger >> ")
                        .font(.system(size: CGFloat(12)))
                    Text("\(getFormattedString(selectedOrganism.hunger))")
                        .font(.system(size: CGFloat(12)))
                        .foregroundColor(.secondary)
                }
                HStack {
                    Text("Thirst >> ")
                        .font(.system(size: CGFloat(12)))
                    Text("\(getFormattedString(selectedOrganism.thirst))")
                        .font(.system(size: CGFloat(12)))
                        .foregroundColor(.secondary)
                }
                HStack {
                    Text("Urge >> ")
                        .font(.system(size: CGFloat(12)))
                    Text("\(getFormattedString(selectedOrganism.urge))")
                        .font(.system(size: CGFloat(12)))
                        .foregroundColor(.secondary)
                }
                HStack {
                    Text("Kills >> ")
                        .font(.system(size: CGFloat(12)))
                    Text("\(getFormattedString(selectedOrganism.kills))")
                        .font(.system(size: CGFloat(12)))
                        .foregroundColor(.secondary)
                }
            }
            .frame(width: 200, height: 100, alignment: .center)
            .background(Color.clear)
        }
        .frame(width: 200, alignment: .center)
        .sheet(isPresented: $showGenome) {
            geneView(model: model, selectedOrganism: selectedOrganism, showModal: $showGenome)
        }
    }
    
    func getFormattedString(_ input: Any) -> String {
        let formatter = NumberFormatter()
        formatter.maximumFractionDigits = 2
        formatter.minimumFractionDigits = 0
        formatter.numberStyle = .decimal
        
        if let formattedString = formatter.string(for: input) {
            return formattedString
        } else {
            return "\(input)"
        }
    }
}

public struct geneView: View {
    @State var model: CoreHandler
    @State var selectedOrganism: LifeForm
    @Binding var showModal: Bool
    @State var update: Bool = false

    @Environment(\.colorScheme) var colorScheme

    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
    ]

    public var body: some View {
        VStack {
            ZStack(alignment: Alignment(horizontal: .center, vertical: .top)) {
                VStack {
                    HStack {
                        Button("Close") {
                            selectedOrganism.applyGenes()
                            showModal.toggle()
                        }
                        .frame(width: 55, height: 35)
                        .background(Color(UIColor.systemRed))
                        .foregroundColor(.white)
                        .cornerRadius(7)
                        .padding()
                        Spacer()
                    }
                    HStack(alignment: VerticalAlignment.center) {
                        Text(selectedOrganism.genus.representation)
                            .font(.system(size: 100, design: .monospaced))
                        VStack {
                            Text(selectedOrganism.genus.name)
                                .font(.system(size: 40, design: .monospaced))
                            Text(selectedOrganism.id)
                                .font(.system(size: 10, design: .monospaced))
                                .foregroundColor(.secondary)
                        }
                        Divider()
                            .frame(height: 100)
                        VStack(alignment: HorizontalAlignment.leading) {
                            Text("Resilience")
                                .font(.system(size: 18, design: .monospaced))
                            Text("\(selectedOrganism.resilience)")
                                .font(.system(size: 14, design: .monospaced))
                                .foregroundColor(.secondary)
                            Text("Strength")
                                .font(.system(size: 18, design: .monospaced))
                            Text("\(selectedOrganism.strength)")
                                .font(.system(size: 14, design: .monospaced))
                                .foregroundColor(.secondary)
                        }

                        Divider()
                            .frame(height: 100)
                        VStack(alignment: HorizontalAlignment.leading) {
                            Text("Desirability")
                                .font(.system(size: 18, design: .monospaced))
                            Text("\(selectedOrganism.desirability)")
                                .font(.system(size: 14, design: .monospaced))
                                .foregroundColor(.secondary)
                            Text("Total Fitness")
                                .font(.system(size: 18, design: .monospaced))
                            Text("\(selectedOrganism.getFitness())")
                                .font(.system(size: 14, design: .monospaced))
                                .foregroundColor(.secondary)
                        }
                    }
                }
                if update {
                    Text("")
                        .hidden()
                }
            }
            HStack {
                Text("Lifeform's Genes")
                    .font(.system(size: 40, design: .monospaced))
                Spacer()
                Button("Kill Lifeform") {
                    sim.lifeForms.remove(selectedOrganism)
                    model.matrix![selectedOrganism.location.row, selectedOrganism.location.column] = Space(nil, type: .Nothing)
                    showModal.toggle()
                    model.update.toggle()
                }
                .frame(width: 175, height: 35)
                .background(Color(UIColor.systemRed))
                .foregroundColor(.white)
                .cornerRadius(7)
                .padding()
            }
            ScrollView([.vertical]) {
                LazyVGrid(columns: columns) {
                    ForEach(0..<selectedOrganism.genome.genes.count, id: \.self) { n in
                        let gene = selectedOrganism.genome.genes[n]
                        VStack {
                            Text(gene.effectSpot == AffectRange.desirability ? "Desirability" : gene.effectSpot == AffectRange.resilience ? "Resilience" : "Strength")
                                .font(.system(size: 18, design: .monospaced))
                                .padding(EdgeInsets(top: 20, leading: 0, bottom: 0, trailing: 0))
                            TextField( "Double Value", value: $selectedOrganism.genome.genes[n].affect, formatter: NumberFormatter.decimal, onCommit: {
                                selectedOrganism.applyGenes()
                                update.toggle()
                            })
                                .font(.system(size: 18, design: .monospaced))
                                .keyboardType(.decimalPad)
                                .foregroundColor(Color(UIColor.label))
                                .frame(width: 100, height: 25)
                                .background(Color(.secondarySystemBackground))
                                .cornerRadius(7)
                            HStack() {
                                Spacer()
                                Text("\(n)")
                                    .font(.system(size: 18, design: .monospaced))
                                    .foregroundColor(.secondary)
                                    .padding()
                            }
                        }
                        .frame(width: 150, height: 115)
                        .background(Color(UIColor.systemBackground))
                        .cornerRadius(7)
                        .padding(5)
                    }
                }
            }
        }
        .background(Color(UIColor.terminalBackground))
    }
    
}
