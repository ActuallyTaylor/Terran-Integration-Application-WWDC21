//
//  ContentView.swift
//  Generations
//
//  Created by Zachary lineman on 4/2/21.
//

import SwiftUI
import Combine

public struct MainView: View {
    @ObservedObject public var tia = TIAHandler()
    @ObservedObject public var model = ContentViewHandler()
    @ObservedObject public var core = CoreHandler()

    @State var showGeneEditor: Bool = false
    @State var genusIndex: Int = 0

    @Environment(\.colorScheme) var colorScheme

    public init() {
        tia.advanceStory()
    }

    public var body: some View {
        ZStack(alignment: Alignment(horizontal: tia.positionTwo, vertical: tia.position)) {
            VStack(spacing: 5) {
                Terminal()
                    .frame(height: model.terminalCollapsed ? 100 : nil)
                    .cornerRadius(radius: 15, corners: model.terminalCollapsed ? [.bottomLeft, .bottomRight] : [])
                    .transition(.opacity)
                if model.viewToShow != .terminal {
                    if model.viewToShow == .simulation {
                        SimView(model: core)
                            .cornerRadius(radius: 15, corners: model.terminalCollapsed ? [.topLeft, .topRight] : [])
                            .transition(.opacity)
                    } else if model.viewToShow == .editor {
                        if !showGeneEditor {
                            SpeciesView(model: core, showGeneEditor: $showGeneEditor, genusIndex: $genusIndex)
                                .cornerRadius(radius: 15, corners: model.terminalCollapsed ? [.topLeft, .topRight] : [])
                                .transition(.opacity)
                        } else {
                            GeneEditorView(model: core, species: core.speciesRegistry[genusIndex], showGeneEditor: $showGeneEditor, index: genusIndex)
                                .cornerRadius(radius: 15, corners: model.terminalCollapsed ? [.topLeft, .topRight] : [])
                                .transition(.opacity)
                        }
                    }
                }
            }
            .background(Color(UIColor.terminalBackgroundOpposite))
            Tia(handler: tia)
        }
    }
}
