//
//  SimView.swift
//  Generations.ios
//
//  Created by Zachary lineman on 4/11/21.
//

import SwiftUI
import Combine

public struct SimView: View {
    @ObservedObject public var model: CoreHandler
    @State var textSize: Int = 9
    @State var text: String = "play"
    @State var showResetAlert: Bool = false
    
    @Environment(\.colorScheme) var colorScheme
    
    public var body: some View {
        ZStack(alignment: Alignment(horizontal: .center, vertical: .center)) {
            if model.update {
                Text("")
                    .hidden()
            }
            VStack {
                ScrollView([.horizontal, .vertical], showsIndicators: false) {
                    LazyVStack(spacing: 3) {
                        ForEach(0..<model.rows, id: \.self) { row in
                            LazyHStack(spacing: 3) {
                                ForEach(0..<model.columns, id: \.self) { column in
                                    cell(model: model, row: row, column: column, textSize: $textSize)
                                }
                            }
                        }
                    }
                }
                .alert(isPresented: $model.finished, content: {
                    Alert(title: Text("Simulation Ended"), message: Text("All life forms have gone extinct, so the simulation has been ended."), dismissButton: .default(Text("Dang it!")))
                })
                
                VStack(spacing: 10) {
                    Text("Generation: \(model.cycle)")
                        .font(.system(size: 14, design: .monospaced))
                    HStack {
                        Button(action: {
                            if model.inSession {
                                showResetAlert = true
                            } else {
                                model.restartSim()
                                text = "play"
                            }
                        }) {
                            Image(systemName: "arrow.triangle.2.circlepath")
                                .font(.system(size: 14, weight: .bold))
                                .frame(width: 30, height: 30)
                                .background(Color(.systemRed))
                                .clipShape(Circle())
                                .foregroundColor(.white)
                        }
                        .alert(isPresented: $showResetAlert) { () -> Alert in
                            let primaryButton = Alert.Button.destructive(Text("Yes")) {
                                model.restartSim()
                                text = "play"
                            }
                            let secondaryButton = Alert.Button.cancel(Text("No")) {}
                            return Alert(title: Text("Are you sure?"), message: Text("This will reset your simulation and all progress will be lost"), primaryButton: primaryButton, secondaryButton: secondaryButton)
                        }
                        Button(action: {
                            if model.updateSim() {
                                text = "pause"
                            } else {
                                text = "play"
                            }
                        }) {
                            Image(systemName: text)
                                .font(.system(size: 18, weight: .regular))
                                .frame(width: 30, height: 30)
                                .background(Color(.systemBlue))
                                .clipShape(Circle())
                                .foregroundColor(.white)
                        }
                        Button(action: {
                            model.fastForwardSim()
                        }) {
                            Image(systemName: "forward")
                                .font(.system(size: 14, weight: .regular))
                                .frame(width: 30, height: 30)
                                .background(Color(.systemOrange))
                                .clipShape(Circle())
                                .foregroundColor(!model.started ? .white : .gray)
                        }
                        .disabled(model.started)
                    }
                    HStack {
                        Stepper("Map Size \(textSize): ", value: $textSize, in: 0...130)
                            .font(.system(size: 16, design: .monospaced))
                            .frame(width: 225, height: 30, alignment: .center)
                            .padding(EdgeInsets(top: 0, leading: 0, bottom: 10, trailing: 0))
                        VStack {
                            HStack {
                                Text("Frame Interval")
                                    .font(.system(size: 18, design: .monospaced))
                                TextField("1", value: $model.frameRate, formatter: NumberFormatter.decimal)
                                    .frame(width: 75, height: 25)
                                    .font(.system(size: 18, design: .monospaced))
                                    .multilineTextAlignment(.center)
                                    .keyboardType(.numberPad)
                                    .background(Color(.secondarySystemBackground))
                                    .cornerRadius(7)
                            }
                            Text("The lower the interval rate the more often it will update")
                                .font(.system(size: 10, design: .monospaced))
                                .foregroundColor(.secondary)
                                .padding(EdgeInsets(top: 0, leading: 5, bottom: 5, trailing: 0))
                        }
                        
                    }
                    
                }
            }
            //Help Zone 2
            HStack {
                VStack(alignment: .center) {
                    Text("Glossary")
                        .font(.system(.title))
                        .multilineTextAlignment(.center)
                    VStack(alignment: .leading) {
                        HStack {
                            Text("🌸")
                                .font(.system(size: 40))
                            Text("This is a food source. A life form needs to be close to a food source to survive.")
                                .font(.system(size: 12, design: .monospaced))
                                .foregroundColor(Color(UIColor.terminalForeground))
                            Spacer()
                        }
                        .frame(width: 260)
                        .padding(10)
                        HStack {
                            Text("🌊")
                                .font(.system(size: 40))
                            Text("This is a water source. A life form needs to be close to a water source to survive.")
                                .font(.system(size: 12, design: .monospaced))
                                .foregroundColor(Color(UIColor.terminalForeground))
                            Spacer()
                        }
                        .frame(width: 260)
                        .padding(10)
                        HStack {
                            Text("🌲")
                                .font(.system(size: 40))
                            Text("This is an open space. A life form can freely move into this space.")
                                .font(.system(size: 12, design: .monospaced))
                                .foregroundColor(Color(UIColor.terminalForeground))
                            Spacer()
                        }
                        .frame(width: 260)
                        .padding(10)
                        
                    }
                }
                .frame(width: 300, height: 500)
                .padding(EdgeInsets(top: 0, leading: 5, bottom: 0, trailing: 0))
                Spacer()
                VStack(alignment: .center) {
                    Text("Glossary")
                        .font(.system(.title))
                        .multilineTextAlignment(.center)
                    VStack(alignment: .leading) {
                        HStack {
                            Image(systemName: "arrow.triangle.2.circlepath")
                                .font(.system(size: 14, weight: .bold))
                                .frame(width: 45, height: 45)
                                .background(Color(.systemRed))
                                .clipShape(Circle())
                                .foregroundColor(.white)
                            Text("This button will reset the simulation. It will clear any progress that your simulation has acquired.")
                                .font(.system(size: 12, design: .monospaced))
                                .foregroundColor(Color(UIColor.terminalForeground))
                            Spacer()
                        }
                        .frame(width: 260)
                        .padding(10)
                        HStack {
                            Image(systemName: text)
                                .font(.system(size: 18, weight: .regular))
                                .frame(width: 45, height: 45)
                                .background(Color(.systemBlue))
                                .clipShape(Circle())
                                .foregroundColor(.white)
                            Text("This button will play or pause the simulation.")
                                .font(.system(size: 12, design: .monospaced))
                                .foregroundColor(Color(UIColor.terminalForeground))
                            Spacer()
                        }
                        .frame(width: 260)
                        .padding(10)
                        HStack() {
                            Image(systemName: "forward")
                                .font(.system(size: 14, weight: .regular))
                                .frame(width: 45, height: 45)
                                .background(Color(.systemOrange))
                                .clipShape(Circle())
                                .foregroundColor(!model.started ? .white : .gray)
                            Text("This button will jump a generation forward.")
                                .font(.system(size: 12, design: .monospaced))
                                .foregroundColor(Color(UIColor.terminalForeground))
                            Spacer()
                        }
                        .frame(width: 260)
                        .padding(10)
                        HStack {
                            TextField("1", value: $model.frameRate, formatter: NumberFormatter.decimal)
                                .frame(width: 25, height: 25)
                                .font(.system(size: 18, design: .monospaced))
                                .multilineTextAlignment(.center)
                                .keyboardType(.numberPad)
                                .background(Color(.secondarySystemBackground))
                                .cornerRadius(7)
                                .disabled(true)
                            Text("Changing the frame interval of the simulation will change how often the screen updates. If the simulation is running slowly try to increase this number.")
                                .font(.system(size: 12, design: .monospaced))
                                .foregroundColor(Color(UIColor.terminalForeground))
                            
                        }
                        .frame(width: 260)
                        .padding(10)
                    }
                }
                .frame(width: 300, height: 500)
                .padding(EdgeInsets(top: 0, leading: 5, bottom: 0, trailing: 0))
            }
        }
        .background(Color(UIColor.terminalBackground))
    }
}

