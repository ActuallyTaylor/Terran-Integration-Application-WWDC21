//
//  TIA.swift
//  Generations.ios
//
//  Created by Zachary lineman on 4/14/21.
//

import SwiftUI

struct Tia: View {
    @ObservedObject public var handler: TIAHandler

    @Environment(\.colorScheme) var colorScheme

    init(handler: TIAHandler) {
        self.handler = handler
    }
    
    var body: some View {
        VStack(alignment: HorizontalAlignment.center) {
            if handler.position == .top || handler.position == .center {
                Eye(handler: handler)
                    .padding(EdgeInsets(top: 20, leading: 20, bottom: 5, trailing: 20))
                Prompt(handler: handler)
            } else {
                Prompt(handler: handler)
                Eye(handler: handler)
                    .padding(EdgeInsets(top: 5, leading: 20, bottom: 20, trailing: 20))
            }
        }
    }
}

struct Prompt: View {
    @ObservedObject public var handler: TIAHandler
    
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        ZStack(alignment: Alignment(horizontal: HorizontalAlignment.center, vertical: VerticalAlignment.top)) {
            if !handler.showQuestions {
                HStack {
                    if handler.lastStorySection != nil {
                        Button(action: {
                            handler.back()
                        }, label: {
                            Image(systemName: "backward.fill")
                                .foregroundColor(.secondary)
                                .font(.system(size: 14, weight: .regular))
                                .padding(5)
                        })
                    } else if handler.nextStorySection != nil {
                        Button(action: {
                            handler.dismiss()
                        }, label: {
                            Image(systemName: "xmark")
                                .foregroundColor(.secondary)
                                .font(.system(size: 14, weight: .regular))
                                .padding(5)
                        })
                    }
                    Spacer()
                    if handler.nextStorySection != nil {
                        Button(action: {
                            handler.next()
                        }, label: {
                            Image(systemName: "forward.fill")
                                .foregroundColor(.secondary)
                                .font(.system(size: 14, weight: .regular))
                                .padding(5)
                        })
                    } else {
                        Button(action: {
                            handler.dismiss()
                        }, label: {
                            Image(systemName: "xmark")
                                .foregroundColor(.secondary)
                                .font(.system(size: 14, weight: .regular))
                                .padding(5)
                        })
                    }
                }
            }
            VStack(spacing: 0) {
                Text("\(handler.text)")
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
                    .transition(.opacity)
                    .padding()
                    .font(.system(size: 14, design: .monospaced))
                VStack {
                    if handler.questions.count <= 2 {
                        Divider()
                        HStack {
                            ForEach(handler.questions, id: \.self) { question in
                                Spacer()
                                Button(question) {
                                    handler.advanceStory(question)
                                }
                                    .padding(EdgeInsets(top: 0, leading: 0, bottom: 10, trailing: 0))
                                    .font(.system(size: 14, design: .monospaced))
                                Spacer()
                                Divider()
                            }
                        }
                    } else {
                        VStack {
                            ForEach(handler.questions, id: \.self) { question in
                                Divider()
                                Button(question) {
                                    handler.advanceStory(question)
                                }
                                    .frame(height: 25)
                                    .font(.system(size: 14, design: .monospaced))
                            }
                        }
                    }
                }
                .frame(height: (handler.questions.count <= 2 && handler.questions.count != 0) ? 45 : CGFloat(45 * handler.questions.count), alignment: .center)
                .hidden(!handler.showQuestions)
            }
        }
        .transition(.scale)
        .background(VisualEffectView(effect: UIBlurEffect(style: .dark)).cornerRadius(7))
        .frame(minWidth: .zero, idealWidth: handler.promptShown ? 200 : 0, maxWidth: handler.promptShown ? 400 : 0)
        .hidden(!handler.promptShown)
        .padding(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: handler.positionTwo == HorizontalAlignment.center ? 0 : 20))
    }
}

struct Eye: View {
    @ObservedObject public var handler: TIAHandler

    @State var animate: Bool = false
    @State var inChange: Bool = false
    
    @State var shake: Int = 0

    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        ZStack(alignment: Alignment(horizontal: .center, vertical: .center)) {
            Circle()
                .stroke(Color(.cyan), lineWidth: 10)
                .frame(width: 50, height: 50, alignment: .center)
                .cornerRadius(32.5)
                .scaleEffect(animate ? 1.2: 1.0)
                .animation(Animation.easeInOut(duration: 3).repeatForever(autoreverses: true))
                .background(Circle().foregroundColor(handler.eyeColor))
                .animation(Animation.easeInOut(duration: handler.eyeTime))
                .modifier(Shake(animatableData: CGFloat(shake)))
                
                .onAppear {
                    animate.toggle()
                }
                .onTapGesture {
                    if handler.angry {
                        handler.eyeTime = 0.1
                        withAnimation {
                            self.shake += 1
                        }
                        inChange = true
                        handler.eyeColor = (handler.eyeColor == Color.black) ? Color.red : Color.black
                        Dispatch.delay(seconds: 0.5) {
                            inChange = false
                            handler.eyeColor = (handler.eyeColor == Color.black) ? Color.red : Color.black
                        }
                    } else {
                        handler.eyeTime = 0.1
                        handler.faq()
                        withAnimation {
                            self.shake += 1
                        }
                        inChange = true
                        handler.eyeColor = (handler.eyeColor == Color.black) ? Color.green : Color.black
                        Dispatch.delay(seconds: 0.5) {
                            inChange = false
                            handler.eyeColor = (handler.eyeColor == Color.black) ? Color.green : Color.black
                        }
                    }
                }
//                Orbital(width: 85, height: 85, reversed: false, color: Color(.gray))
//                Orbital(width: 60, height: 60, reversed: true, color: Color(UIColor.systemGray2))
        }
        .frame(width: 50, height: 50, alignment: .center)
        .fixedSize(horizontal: true, vertical: true)
    }
}

struct Orbital: View {
    @State private var isLoading = false
    @State var width: CGFloat
    @State var height: CGFloat
    
    @State var reversed: Bool
    
    @State var color: Color
    
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        ZStack(alignment: Alignment(horizontal: .center, vertical: .center)) {
            //Sphere One
            Circle()
                .trim(from: 0, to: 0.27)
                .stroke(color, lineWidth: 3)
                .frame(width: width, height: height)
            Circle()
                .trim(from: 0.33, to: 0.63)
                .stroke(color, lineWidth: 3)
                .frame(width: width, height: height)
            Circle()
                .trim(from: 0.7, to: 0.95)
                .stroke(color, lineWidth: 3)
                .frame(width: width, height: height)
        }
        .rotationEffect(Angle(degrees: reversed ? isLoading ? -360 : 0 : isLoading ? 360 : 0))
        .animation(Animation.linear(duration: 5).repeatForever(autoreverses: false))
        .frame(width: width, height: height, alignment: .center)
        .fixedSize(horizontal: true, vertical: true)
        .onAppear() {
            self.isLoading = true
        }
    }
}

//https://stackoverflow.com/questions/56490250/dynamically-hiding-view-in-swiftui
extension View {
    @ViewBuilder func hidden(_ shouldHide: Bool) -> some View {
        switch shouldHide {
        case true: self.hidden()
        case false: self
        }
    }
}

//https://stackoverflow.com/questions/56610957/is-there-a-method-to-blur-a-background-in-swiftui
struct VisualEffectView: UIViewRepresentable {
    var effect: UIVisualEffect?
    func makeUIView(context: UIViewRepresentableContext<Self>) -> UIVisualEffectView { UIVisualEffectView() }
    func updateUIView(_ uiView: UIVisualEffectView, context: UIViewRepresentableContext<Self>) { uiView.effect = effect }
}

//https://www.objc.io/blog/2019/10/01/swiftui-shake-animation/
struct Shake: GeometryEffect {
    var amount: CGFloat = 2
    var shakesPerUnit = 2
    var animatableData: CGFloat

    func effectValue(size: CGSize) -> ProjectionTransform {
        var value = amount * sin(animatableData * .pi * CGFloat(shakesPerUnit))
        let x = Random.bool() ? value : value.flip()
        let y = Random.bool() ? value : value.flip()
        return ProjectionTransform(CGAffineTransform(translationX: x, y: y))
    }
}

extension CGFloat {
    
    mutating func flip() -> CGFloat {
        var n = self
        n.negate()
        return n
    }
}
