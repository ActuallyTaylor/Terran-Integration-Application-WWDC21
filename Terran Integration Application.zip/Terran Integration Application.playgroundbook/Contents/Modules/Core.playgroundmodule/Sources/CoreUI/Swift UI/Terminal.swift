//
//  Terminal.swift
//  Generations.ios
//
//  Created by Zachary lineman on 4/14/21.
//

import SwiftUI

public struct Terminal: View {

    @Environment(\.colorScheme) var colorScheme

    @State var terminalText: String = "Welcome to T.I.A!\n\nBecause of a Swift UI bug the terminal may sometimes clear the current line or not be clickable. To fix this hit the tab key.\n\nFor a list of commands type ➔ -help-\n\n\(startingSequence)"
    
    public var body: some View {
        TerminalView(text: $terminalText)
    }
}
