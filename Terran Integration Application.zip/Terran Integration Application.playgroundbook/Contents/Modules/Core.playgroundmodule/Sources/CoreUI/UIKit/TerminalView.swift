//
//  TerminalView.swift
//  Generations
//
//  Created by Zachary lineman on 4/11/21.
//

import Foundation
import UIKit
import SwiftUI

var startingSequence: String = "➔ ~ ￼"

//Handles everything that has to deal with the terminal
public struct TerminalView: UIViewRepresentable {
 
    @Binding var text: String
    let textView = UITextView()

    public func makeUIView(context: Context) -> UITextView {
        textView.autocapitalizationType = .none
        textView.isSelectable = true
        textView.isUserInteractionEnabled = true
        textView.delegate = context.coordinator
        textView.becomeFirstResponder()
        textView.backgroundColor = .terminalBackground
        textView.textColor = .terminalForeground
        textView.tintColor = .terminalSelection
        
        let monospacedBody = UIFont.monospacedSystemFont(ofSize: 12, weight: .regular)
        textView.font = monospacedBody
        
        return textView
    }
 
    public func updateUIView(_ uiView: UITextView, context: Context) {
        uiView.text = text
    }
    
    public func makeCoordinator() -> Coordinator {
        Coordinator($text, textView)
    }
    
    public func reset() {
        text = "Welcome to T.I.A!\n\nBecause of a Swift UI bug the terminal may sometimes clear the current line or not be clickable. To fix this hit the tab key.\n\nFor a list of commands type ➔ -help-\n\n\(startingSequence)"
    }

    public class Coordinator: NSObject, UITextViewDelegate {
        var text: Binding<String>
        let textView: UITextView

        public init(_ text: Binding<String>, _ textView: UITextView) {
            self.text = text
            self.textView = textView
        }

        public func textViewDidChange(_ textView: UITextView) {
            self.text.wrappedValue = textView.text
        }
        
        public func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
//            let selectedRange = textView.selectedRange
            if let char = text.cString(using: String.Encoding.utf8) {
                let isBackSpace = strcmp(char, "\\b")
                if (isBackSpace == -92) {
                    if range.length > 0 {
                        let replacedCharacters = (textView.text as NSString).substring(with: range)
                        if replacedCharacters == "￼" {
                            return false
                        }
                    }
                }
            }
            
            if text == "\n" {
                let command = getLineString().replacingOccurrences(of: startingSequence, with: "").lowercased().trim()
                
                if command == "" {
                    let insertingText = "\n\(startingSequence)"
                    
                    self.textView.text += insertingText
                    self.text.wrappedValue = textView.text
//                    textView.textStorage.replaceCharacters(in: selectedRange, with: insertingText)
//                    let newPosition = textView.endOfDocument
//                    textView.selectedTextRange = textView.textRange(from: newPosition, to: newPosition)
                    
                    return false
                } else if command == "help" {
                    let insertingText = "\nWelcome to the T.I.A help.\nT.I.A stands for Terran Integration Application\nT.I.A is used to simulate life forms in a population.\n\nThe following commands are used to talk with T.I.A\n➔ help - Displays this list of commands\n➔ start - Starts a genetic simulation\n➔ edit - Allows you to edit the simulation settings.\n➔ exit - closes T.I.A\n➔ clear - clears the terminal\n\n\(startingSequence)"
                    
                    self.textView.text += insertingText
                    self.text.wrappedValue = textView.text
//                    textView.textStorage.replaceCharacters(in: selectedRange, with: insertingText)
//                    let newPosition = textView.endOfDocument
//                    textView.selectedTextRange = textView.textRange(from: newPosition, to: newPosition)
                    
                    return false
                } else if command == "start" || "command" == "sim" {
                    
                    let insertingText = "\n\(startingSequence)"
                    
                    self.textView.text += insertingText
                    self.text.wrappedValue = textView.text
//                    textView.textStorage.replaceCharacters(in: selectedRange, with: insertingText)
//                    let newPosition = textView.endOfDocument
//                    textView.selectedTextRange = textView.textRange(from: newPosition, to: newPosition)

                    NotificationCenter.default.post(Notification(name: .StartSim))
                    return false
                } else if command == "exit" || command == "close" {
                    let insertingText = "\n\(startingSequence)"
                    
                    self.textView.text += insertingText
                    self.text.wrappedValue = textView.text
//                    textView.textStorage.replaceCharacters(in: selectedRange, with: insertingText)
//                    let newPosition = textView.endOfDocument
//                    textView.selectedTextRange = textView.textRange(from: newPosition, to: newPosition)

                    NotificationCenter.default.post(Notification(name: .StartTerminal))
                    return false
                } else if command == "edit" {
                    let insertingText = "\n\(startingSequence)"
                    
                    self.textView.text += insertingText
                    self.text.wrappedValue = textView.text
//                    textView.textStorage.replaceCharacters(in: selectedRange, with: insertingText)
//                    let newPosition = textView.endOfDocument
//                    textView.selectedTextRange = textView.textRange(from: newPosition, to: newPosition)
                    
                    NotificationCenter.default.post(Notification(name: .StartGeneEditing))
                    return false
                }  else if command == "clear" {
                    let newText = "Welcome to T.I.A!\n\nBecause of a Swift UI bug the terminal may sometimes clear the current line or not be clickable. To fix this hit the tab key.\n\nFor a list of commands type ➔ -help-\n\n\(startingSequence)"
                    
                    textView.text = newText
                    self.text.wrappedValue = textView.text
//                    let newPosition = textView.endOfDocument
//                    textView.selectedTextRange = textView.textRange(from: newPosition, to: newPosition)
                    
                    return false
                } else {
                    let insertingText = "\nCommand not found: \(command)\n\(startingSequence)"
                    
                    self.textView.text += insertingText
                    self.text.wrappedValue = textView.text
//                    textView.textStorage.replaceCharacters(in: selectedRange, with: insertingText)
//                    let newPosition = textView.endOfDocument
//                    textView.selectedTextRange = textView.textRange(from: newPosition, to: newPosition)
                    return false
                }
            }
            return true
        }
        
        public func textViewDidChangeSelection(_ textView: UITextView) {
            let newPosition = textView.endOfDocument
            textView.selectedTextRange = textView.textRange(from: newPosition, to: newPosition)
        }
        
        public func getLineString() -> String {
            return (self.textView.text! as NSString).substring(with: (self.textView.text as NSString).lineRange(for: self.textView.selectedRange))
        }
        
        public func updateSelectedRange(_ range: NSRange) {
            if range.location + range.length <= textView.text.utf8.count {
                textView.selectedRange = range
            }
        }
    }
}

extension String {
    func trim() -> String {
        return self.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
