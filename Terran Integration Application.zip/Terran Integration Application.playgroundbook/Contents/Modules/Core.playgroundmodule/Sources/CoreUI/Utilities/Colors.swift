//
//  Colors.swift
//  Generations.ios
//
//  Created by Zachary lineman on 4/12/21.
//

import SwiftUI

//Colors for the terminal
extension UIColor {
    public static var terminalForeground: UIColor {
        get {
            let style = UITraitCollection.current.userInterfaceStyle
            if style == .dark {
                return UIColor(red: 192/255, green: 197/255, blue: 206/255, alpha: 1.0)
            } else {
                return UIColor(red: 79/255, green: 91/255, blue: 102/255, alpha: 1.0)
            }
        }
    }
    
    public static var terminalBackground: UIColor {
        get {
            let style = UITraitCollection.current.userInterfaceStyle
            if style == .dark {
                return UIColor(red: 43/255, green: 48/255, blue: 59/255, alpha: 1.0)
            } else {
                return UIColor(red: 239/255, green: 241/255, blue: 245/255, alpha: 1.0)
            }
        }
    }

    public static var terminalSelection: UIColor {
        get {
            let style = UITraitCollection.current.userInterfaceStyle
            if style == .dark {
                return UIColor(red: 79/255, green: 91/255, blue: 102/255, alpha: 1.0)
            } else {
                return UIColor(red: 192/255, green: 197/255, blue: 206/255, alpha: 1.0)
            }
        }
    }

    public static var terminalBackgroundOpposite: UIColor {
        get {
            let style = UITraitCollection.current.userInterfaceStyle
            if style == .dark {
                return UIColor(red: 239/255, green: 241/255, blue: 245/255, alpha: 1.0)
            } else {
                return UIColor(red: 43/255, green: 48/255, blue: 59/255, alpha: 1.0)
            }
        }
    }

    
    public static var terminalForegroundOpposite: UIColor {
        get {
            let style = UITraitCollection.current.userInterfaceStyle
            if style == .dark {
                return UIColor(red: 79/255, green: 91/255, blue: 102/255, alpha: 1.0)
            } else {
                return UIColor(red: 192/255, green: 197/255, blue: 206/255, alpha: 1.0)
            }
        }
    }

}
//
