//
//  Notification.swift
//  Generations.ios
//
//  Created by Zachary lineman on 4/11/21.
//

import Foundation

//Extension for notifications to just make it easier.
extension Notification.Name {
    static let StartSim = Notification.Name("StartSim")
    static let StartTerminal = Notification.Name("StartTerminal")
    static let StartGeneEditing = Notification.Name("StartEditor")
    static let ResetSim = Notification.Name("ResetSim")
    static let NewQuip = Notification.Name("NewQuip")
    static let Faq = Notification.Name("Faq")
    static let StartGenusEditing = Notification.Name("StartGenusEditing")
    static let StartGeneEditingTutorial = Notification.Name("StartGeneEditingTutorial")
    static let ReloadSim = Notification.Name("ReloadSim")

}

